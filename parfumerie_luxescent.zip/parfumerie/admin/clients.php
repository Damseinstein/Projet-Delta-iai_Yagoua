<?php
require_once '../includes/config.php';
if (!isAdmin()) redirect(SITE_URL . '/pages/login.php');
$pageTitle = 'Clients - Admin LUXE SCENT';
$success = '';

// Activer/désactiver un client
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $pdo->prepare("UPDATE utilisateurs SET actif = !actif WHERE id = ? AND role = 'client'")->execute([$id]);
    $success = 'Statut client mis à jour.';
}

$clients = $pdo->query("
    SELECT u.*, 
           COUNT(DISTINCT c.id) as nb_commandes,
           COALESCE(SUM(c.total), 0) as total_achats
    FROM utilisateurs u 
    LEFT JOIN commandes c ON u.id = c.utilisateur_id AND c.statut != 'annulee'
    WHERE u.role = 'client'
    GROUP BY u.id
    ORDER BY u.date_inscription DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1 class="admin-page-title">Clients</h1>
      <span style="color:#888;font-size:0.82rem;"><?= count($clients) ?> client(s) inscrit(s)</span>
    </div>

    <?php if ($success): ?><div class="alert alert-success">✓ <?= $success ?></div><?php endif; ?>

    <div class="admin-card">
      <div class="admin-card-header">
        <span class="admin-card-title">Tous les Clients</span>
        <input type="text" placeholder="Rechercher..." oninput="filterTable(this.value)"
               style="background:var(--gris-moyen);border:1px solid rgba(201,169,110,0.2);color:var(--blanc);padding:0.4rem 0.75rem;font-size:0.8rem;outline:none;">
      </div>
      <div style="overflow-x:auto;">
        <table class="admin-table" id="clientTable">
          <thead>
            <tr><th>Client</th><th>Email</th><th>Téléphone</th><th>Commandes</th><th>CA</th><th>Inscrit le</th><th>Statut</th><th>Action</th></tr>
          </thead>
          <tbody>
            <?php foreach ($clients as $c): ?>
            <tr>
              <td>
                <div style="display:flex;align-items:center;gap:0.75rem;">
                  <div style="width:36px;height:36px;background:rgba(201,169,110,0.15);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.85rem;color:var(--or);font-weight:500;">
                    <?= strtoupper(substr($c['prenom'],0,1).substr($c['nom'],0,1)) ?>
                  </div>
                  <div>
                    <div><?= htmlspecialchars($c['prenom'].' '.$c['nom']) ?></div>
                  </div>
                </div>
              </td>
              <td style="color:#888;font-size:0.82rem;"><?= htmlspecialchars($c['email']) ?></td>
              <td style="color:#888;font-size:0.82rem;"><?= htmlspecialchars($c['telephone'] ?? '-') ?></td>
              <td style="text-align:center;">
                <span style="background:rgba(201,169,110,0.15);color:var(--or);padding:0.2rem 0.6rem;font-size:0.75rem;"><?= $c['nb_commandes'] ?></span>
              </td>
              <td style="color:var(--or)"><?= formatPrice($c['total_achats']) ?></td>
              <td style="font-size:0.78rem;color:#888"><?= date('d/m/Y', strtotime($c['date_inscription'])) ?></td>
              <td>
                <span class="badge badge-<?= $c['actif'] ? 'actif' : 'inactif' ?>"><?= $c['actif'] ? 'Actif' : 'Suspendu' ?></span>
              </td>
              <td>
                <a href="?toggle=<?= $c['id'] ?>" class="btn btn-dark btn-sm"
                   data-confirm="<?= $c['actif'] ? 'Suspendre ce client ?' : 'Réactiver ce client ?' ?>">
                  <?= $c['actif'] ? '🚫 Suspendre' : '✓ Réactiver' ?>
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
<script>
function filterTable(q) {
  q = q.toLowerCase();
  document.querySelectorAll('#clientTable tbody tr').forEach(r => {
    r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
</script>
</body>
</html>
