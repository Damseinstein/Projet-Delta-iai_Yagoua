<?php
require_once '../includes/config.php';
if (!isAdmin()) redirect(SITE_URL . '/pages/login.php');
$pageTitle = 'Catégories - Admin LUXE SCENT';
$success = '';
$error = '';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $count = $pdo->prepare("SELECT COUNT(*) FROM produits WHERE categorie_id = ?")->execute([$id]) ? $pdo->query("SELECT COUNT(*) FROM produits WHERE categorie_id = $id")->fetchColumn() : 0;
    if ($count > 0) {
        $error = "Cette catégorie contient $count produit(s). Réaffectez-les d'abord.";
    } else {
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        $success = 'Catégorie supprimée.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = sanitize($_POST['nom'] ?? '');
    $desc = sanitize($_POST['description'] ?? '');
    $editId = (int)($_POST['edit_id'] ?? 0);
    if (!$nom) {
        $error = 'Le nom est obligatoire.';
    } elseif ($editId) {
        $pdo->prepare("UPDATE categories SET nom=?, description=? WHERE id=?")->execute([$nom, $desc, $editId]);
        $success = 'Catégorie mise à jour.';
    } else {
        $pdo->prepare("INSERT INTO categories (nom, description) VALUES (?,?)")->execute([$nom, $desc]);
        $success = 'Catégorie créée.';
    }
}

$categories = $pdo->query("SELECT c.*, COUNT(p.id) as nb_produits FROM categories c LEFT JOIN produits p ON c.id = p.categorie_id GROUP BY c.id ORDER BY c.nom")->fetchAll();
$editCat = null;
if (isset($_GET['edit'])) {
    $editCat = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $editCat->execute([(int)$_GET['edit']]);
    $editCat = $editCat->fetch();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1 class="admin-page-title">Catégories</h1>
    </div>

    <?php if ($success): ?><div class="alert alert-success">✓ <?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error">⚠ <?= $error ?></div><?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 380px;gap:1.5rem;">
      <div class="admin-card">
        <div class="admin-card-header"><span class="admin-card-title">Toutes les catégories</span></div>
        <table class="admin-table">
          <thead><tr><th>Nom</th><th>Description</th><th>Produits</th><th>Actions</th></tr></thead>
          <tbody>
            <?php foreach ($categories as $cat): ?>
            <tr>
              <td style="font-weight:500;color:var(--or)"><?= htmlspecialchars($cat['nom']) ?></td>
              <td style="color:#888;font-size:0.8rem;"><?= htmlspecialchars(substr($cat['description'] ?? '', 0, 60)) ?><?= strlen($cat['description'] ?? '') > 60 ? '...' : '' ?></td>
              <td style="text-align:center;"><span class="badge badge-or"><?= $cat['nb_produits'] ?></span></td>
              <td>
                <div style="display:flex;gap:0.4rem;">
                  <a href="?edit=<?= $cat['id'] ?>" class="btn btn-dark btn-sm">✏️</a>
                  <a href="?delete=<?= $cat['id'] ?>" class="btn btn-danger btn-sm" data-confirm="Supprimer cette catégorie ?">🗑️</a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="admin-card">
        <div class="admin-card-header">
          <span class="admin-card-title"><?= $editCat ? 'Modifier' : 'Nouvelle' ?> Catégorie</span>
        </div>
        <div class="admin-card-body">
          <form method="POST">
            <?php if ($editCat): ?>
            <input type="hidden" name="edit_id" value="<?= $editCat['id'] ?>">
            <?php endif; ?>
            <div class="form-group">
              <label class="form-label">Nom *</label>
              <input type="text" name="nom" class="form-control" required placeholder="Eau de Parfum"
                     value="<?= htmlspecialchars($editCat['nom'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Description</label>
              <textarea name="description" class="form-control" placeholder="Description..."><?= htmlspecialchars($editCat['description'] ?? '') ?></textarea>
            </div>
            <div style="display:flex;gap:0.75rem;">
              <button type="submit" class="btn btn-primary"><?= $editCat ? '✓ Modifier' : '+ Créer' ?></button>
              <?php if ($editCat): ?><a href="categories.php" class="btn btn-dark">Annuler</a><?php endif; ?>
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
