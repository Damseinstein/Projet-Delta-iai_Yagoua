<?php
require_once '../includes/config.php';
if (!isAdmin()) redirect(SITE_URL . '/pages/login.php');
$pageTitle = 'Codes Promo - Admin LUXE SCENT';
$success = '';
$error = '';

// Supprimer
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM codes_promo WHERE id = ?")->execute([(int)$_GET['delete']]);
    $success = 'Code promo supprimé.';
}

// Toggle actif
if (isset($_GET['toggle'])) {
    $pdo->prepare("UPDATE codes_promo SET actif = !actif WHERE id = ?")->execute([(int)$_GET['toggle']]);
    $success = 'Statut mis à jour.';
}

// Ajouter
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_promo'])) {
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $reduction = (float)($_POST['reduction'] ?? 0);
    $type = $_POST['type_reduction'] ?? 'pourcentage';
    $debut = $_POST['date_debut'] ?? null;
    $fin = $_POST['date_fin'] ?? null;
    $max = (int)($_POST['utilisation_max'] ?? 100);

    if (!$code || $reduction <= 0) {
        $error = 'Code et réduction sont obligatoires.';
    } else {
        try {
            $pdo->prepare("INSERT INTO codes_promo (code, reduction, type_reduction, date_debut, date_fin, utilisation_max) VALUES (?,?,?,?,?,?)")
                ->execute([$code, $reduction, $type, $debut ?: null, $fin ?: null, $max]);
            $success = "Code promo $code créé.";
        } catch (PDOException $e) {
            $error = 'Ce code existe déjà.';
        }
    }
}

$promos = $pdo->query("SELECT * FROM codes_promo ORDER BY created_at DESC 2>/dev/null || SELECT *, CURRENT_TIMESTAMP as created_at FROM codes_promo ORDER BY id DESC")->fetchAll();
if (!$promos) {
    $promos = $pdo->query("SELECT * FROM codes_promo ORDER BY id DESC")->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1 class="admin-page-title">Codes Promo</h1>
    </div>

    <?php if ($success): ?><div class="alert alert-success">✓ <?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error">⚠ <?= $error ?></div><?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 380px;gap:1.5rem;">
      <!-- Liste -->
      <div class="admin-card">
        <div class="admin-card-header"><span class="admin-card-title">Codes Actifs</span></div>
        <table class="admin-table">
          <thead>
            <tr><th>Code</th><th>Réduction</th><th>Validité</th><th>Utilisations</th><th>Statut</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach ($promos as $p): ?>
            <tr>
              <td style="font-weight:500;color:var(--or);letter-spacing:0.1em;"><?= htmlspecialchars($p['code']) ?></td>
              <td>
                <?php if ($p['type_reduction'] === 'pourcentage'): ?>
                  <span style="color:#2ecc71"><?= $p['reduction'] ?>%</span>
                <?php else: ?>
                  <span style="color:#2ecc71">-<?= formatPrice($p['reduction']) ?></span>
                <?php endif; ?>
              </td>
              <td style="font-size:0.78rem;color:#888;">
                <?= $p['date_debut'] ? date('d/m/Y', strtotime($p['date_debut'])) : '∞' ?>
                →
                <?= $p['date_fin'] ? date('d/m/Y', strtotime($p['date_fin'])) : '∞' ?>
              </td>
              <td style="text-align:center;">
                <?= $p['utilisation_actuelle'] ?> / <?= $p['utilisation_max'] ?>
              </td>
              <td><span class="badge badge-<?= $p['actif'] ? 'actif' : 'inactif' ?>"><?= $p['actif'] ? 'Actif' : 'Inactif' ?></span></td>
              <td>
                <div style="display:flex;gap:0.4rem;">
                  <a href="?toggle=<?= $p['id'] ?>" class="btn btn-dark btn-sm"><?= $p['actif'] ? 'Désact.' : 'Act.' ?></a>
                  <a href="?delete=<?= $p['id'] ?>" class="btn btn-danger btn-sm" data-confirm="Supprimer ce code ?">🗑️</a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Formulaire -->
      <div class="admin-card">
        <div class="admin-card-header"><span class="admin-card-title">Nouveau Code</span></div>
        <div class="admin-card-body">
          <form method="POST">
            <div class="form-group">
              <label class="form-label">Code promo *</label>
              <input type="text" name="code" class="form-control" placeholder="ETE2024" required 
                     style="text-transform:uppercase;font-weight:500;letter-spacing:0.1em;">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
              <div class="form-group">
                <label class="form-label">Réduction *</label>
                <input type="number" name="reduction" class="form-control" placeholder="10" min="0" step="0.01" required>
              </div>
              <div class="form-group">
                <label class="form-label">Type</label>
                <select name="type_reduction" class="form-control">
                  <option value="pourcentage">% Pourcentage</option>
                  <option value="montant">€ Montant fixe</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Date début</label>
              <input type="date" name="date_debut" class="form-control" value="<?= date('Y-m-d') ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Date fin</label>
              <input type="date" name="date_fin" class="form-control">
            </div>
            <div class="form-group">
              <label class="form-label">Utilisations max</label>
              <input type="number" name="utilisation_max" class="form-control" value="100" min="1">
            </div>
            <button type="submit" name="add_promo" class="btn btn-primary w-100" style="justify-content:center;">Créer le code</button>
          </form>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
