<?php
require_once '../includes/config.php';

if (!isAdmin()) redirect(SITE_URL . '/pages/login.php');

$pageTitle = 'Dashboard - Admin LUXE SCENT';

// Stats
$stats = [
    'produits' => $pdo->query("SELECT COUNT(*) FROM produits WHERE statut='actif'")->fetchColumn(),
    'commandes' => $pdo->query("SELECT COUNT(*) FROM commandes")->fetchColumn(),
    'clients' => $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role='client'")->fetchColumn(),
    'ca' => $pdo->query("SELECT COALESCE(SUM(total), 0) FROM commandes WHERE statut != 'annulee'")->fetchColumn(),
];

// Dernières commandes
$recentOrders = $pdo->query("
    SELECT c.*, u.prenom, u.nom 
    FROM commandes c LEFT JOIN utilisateurs u ON c.utilisateur_id = u.id 
    ORDER BY c.date_commande DESC LIMIT 8
")->fetchAll();

// Produits bas stock
$lowStock = $pdo->query("SELECT * FROM produits WHERE stock <= 5 AND statut='actif' ORDER BY stock ASC LIMIT 5")->fetchAll();

// Produits les plus vendus
$topProducts = $pdo->query("
    SELECT p.nom, p.marque, SUM(lc.quantite) as total_vendu, SUM(lc.quantite * lc.prix_unitaire) as ca
    FROM lignes_commande lc JOIN produits p ON lc.produit_id = p.id
    GROUP BY p.id ORDER BY total_vendu DESC LIMIT 5
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR -->
  <?php include 'sidebar.php'; ?>

  <!-- MAIN -->
  <main class="admin-main">
    <div class="admin-topbar">
      <h1 class="admin-page-title">Dashboard</h1>
      <div style="display:flex;gap:1rem;align-items:center;">
        <span style="font-size:0.75rem;color:#888;">Bonjour, <strong style="color:var(--or)"><?= htmlspecialchars($_SESSION['prenom']) ?></strong></span>
        <a href="<?= SITE_URL ?>" class="btn btn-outline btn-sm" target="_blank">Voir la boutique</a>
      </div>
    </div>

    <!-- STATS -->
    <div class="stats-grid">
      <div class="stat-card">
        <span class="stat-card-icon">📦</span>
        <span class="stat-card-value"><?= $stats['produits'] ?></span>
        <span class="stat-card-label">Produits actifs</span>
      </div>
      <div class="stat-card">
        <span class="stat-card-icon">🛒</span>
        <span class="stat-card-value"><?= $stats['commandes'] ?></span>
        <span class="stat-card-label">Commandes totales</span>
      </div>
      <div class="stat-card">
        <span class="stat-card-icon">👥</span>
        <span class="stat-card-value"><?= $stats['clients'] ?></span>
        <span class="stat-card-label">Clients inscrits</span>
      </div>
      <div class="stat-card">
        <span class="stat-card-icon">💰</span>
        <span class="stat-card-value"><?= number_format($stats['ca'], 0, ',', ' ') ?>€</span>
        <span class="stat-card-label">Chiffre d'affaires</span>
      </div>
    </div>

    <!-- DERNIÈRES COMMANDES + ALERTES STOCK -->
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;margin-bottom:1.5rem;">
      
      <!-- Dernières commandes -->
      <div class="admin-card">
        <div class="admin-card-header">
          <span class="admin-card-title">Dernières Commandes</span>
          <a href="orders.php" class="btn btn-outline btn-sm">Tout voir</a>
        </div>
        <div style="overflow-x:auto;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Référence</th>
                <th>Client</th>
                <th>Total</th>
                <th>Statut</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recentOrders as $order): ?>
              <tr>
                <td style="color:var(--or);font-size:0.8rem;"><?= htmlspecialchars($order['reference']) ?></td>
                <td><?= htmlspecialchars($order['prenom'] . ' ' . $order['nom']) ?></td>
                <td><?= formatPrice($order['total']) ?></td>
                <td><span class="badge badge-<?= $order['statut'] ?>"><?= str_replace('_', ' ', $order['statut']) ?></span></td>
                <td style="color:#888;font-size:0.8rem;"><?= date('d/m/Y', strtotime($order['date_commande'])) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Alertes stock + Top produits -->
      <div style="display:flex;flex-direction:column;gap:1.5rem;">
        <!-- Alertes -->
        <div class="admin-card">
          <div class="admin-card-header">
            <span class="admin-card-title">⚠ Stock Faible</span>
          </div>
          <div class="admin-card-body">
            <?php if (empty($lowStock)): ?>
              <p style="color:#888;font-size:0.82rem;">Aucune alerte</p>
            <?php else: ?>
              <?php foreach ($lowStock as $p): ?>
              <div style="display:flex;justify-content:space-between;align-items:center;padding:0.5rem 0;border-bottom:1px solid rgba(255,255,255,0.04);font-size:0.82rem;">
                <span><?= htmlspecialchars($p['nom']) ?></span>
                <span style="color:<?= $p['stock'] == 0 ? '#e74c3c' : '#e67e22' ?>;font-weight:500;"><?= $p['stock'] ?></span>
              </div>
              <?php endforeach; ?>
              <a href="products.php" class="btn btn-dark btn-sm" style="margin-top:1rem;width:100%;justify-content:center;">Gérer</a>
            <?php endif; ?>
          </div>
        </div>

        <!-- Top produits -->
        <?php if (!empty($topProducts)): ?>
        <div class="admin-card">
          <div class="admin-card-header">
            <span class="admin-card-title">🏆 Top Ventes</span>
          </div>
          <div class="admin-card-body">
            <?php foreach ($topProducts as $i => $p): ?>
            <div style="display:flex;gap:0.75rem;align-items:center;padding:0.4rem 0;font-size:0.8rem;">
              <span style="color:var(--or);width:16px;text-align:center;"><?= $i+1 ?></span>
              <span style="flex:1;color:var(--blanc);"><?= htmlspecialchars($p['nom']) ?></span>
              <span style="color:#888;"><?= $p['total_vendu'] ?>x</span>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- ACTIONS RAPIDES -->
    <div class="admin-card">
      <div class="admin-card-header">
        <span class="admin-card-title">Actions Rapides</span>
      </div>
      <div class="admin-card-body">
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
          <a href="products.php?action=add" class="btn btn-primary">+ Ajouter un produit</a>
          <a href="products.php" class="btn btn-outline">📦 Gérer les produits</a>
          <a href="orders.php" class="btn btn-outline">🛒 Gérer les commandes</a>
          <a href="clients.php" class="btn btn-outline">👥 Gérer les clients</a>
          <a href="promos.php" class="btn btn-outline">🏷️ Codes promo</a>
        </div>
      </div>
    </div>
  </main>
</div>

<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
