<?php
require_once '../includes/config.php';
if (!isAdmin()) redirect(SITE_URL . '/pages/login.php');

$pageTitle = 'Produits - Admin LUXE SCENT';
$success = '';
$error = '';
$editProduct = null;
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

// SUPPRIMER
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $pdo->prepare("UPDATE produits SET statut = 'inactif' WHERE id = ?")->execute([$id]);
    $success = 'Produit désactivé avec succès.';
    $action = 'list';
}

// RÉACTIVER
if ($action === 'restore' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $pdo->prepare("UPDATE produits SET statut = 'actif' WHERE id = ?")->execute([$id]);
    $success = 'Produit réactivé.';
    $action = 'list';
}

// CHARGER POUR ÉDITION
if ($action === 'edit' && isset($_GET['id'])) {
    $editProduct = $pdo->prepare("SELECT * FROM produits WHERE id = ?");
    $editProduct->execute([(int)$_GET['id']]);
    $editProduct = $editProduct->fetch();
}

// SAUVEGARDER (ajout ou édition)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['action'], ['save_add', 'save_edit'])) {
    $nom = sanitize($_POST['nom'] ?? '');
    $marque = sanitize($_POST['marque'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $prix = (float)($_POST['prix'] ?? 0);
    $prix_promo = !empty($_POST['prix_promo']) ? (float)$_POST['prix_promo'] : null;
    $stock = (int)($_POST['stock'] ?? 0);
    $volume = sanitize($_POST['volume'] ?? '');
    $categorie_id = (int)($_POST['categorie_id'] ?? 0);
    $genre = $_POST['genre'] ?? 'mixte';
    $statut = $_POST['statut'] ?? 'actif';

    if (!$nom || !$marque || $prix <= 0) {
        $error = 'Nom, marque et prix sont obligatoires.';
        $action = $_POST['action'] === 'save_edit' ? 'edit' : 'add';
    } else {
        if ($_POST['action'] === 'save_edit') {
            $id = (int)$_POST['edit_id'];
            $pdo->prepare("UPDATE produits SET nom=?, marque=?, description=?, prix=?, prix_promo=?, stock=?, volume=?, categorie_id=?, genre=?, statut=? WHERE id=?")
                ->execute([$nom, $marque, $description, $prix, $prix_promo, $stock, $volume, $categorie_id ?: null, $genre, $statut, $id]);
            $success = "Produit \"$nom\" mis à jour avec succès.";
        } else {
            $pdo->prepare("INSERT INTO produits (nom, marque, description, prix, prix_promo, stock, volume, categorie_id, genre, statut) VALUES (?,?,?,?,?,?,?,?,?,?)")
                ->execute([$nom, $marque, $description, $prix, $prix_promo, $stock, $volume, $categorie_id ?: null, $genre, $statut]);
            $success = "Produit \"$nom\" ajouté avec succès.";
        }
        $action = 'list';
    }
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY nom")->fetchAll();
$products = $pdo->query("SELECT p.*, c.nom as cat_nom FROM produits p LEFT JOIN categories c ON p.categorie_id = c.id ORDER BY p.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1 class="admin-page-title">
        <?php if ($action === 'add'): ?>Ajouter un Produit
        <?php elseif ($action === 'edit'): ?>Modifier le Produit
        <?php else: ?>Gestion des Produits
        <?php endif; ?>
      </h1>
      <?php if ($action === 'list'): ?>
      <a href="?action=add" class="btn btn-primary">+ Nouveau Produit</a>
      <?php else: ?>
      <a href="products.php" class="btn btn-dark">← Retour</a>
      <?php endif; ?>
    </div>

    <?php if ($success): ?><div class="alert alert-success">✓ <?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error">⚠ <?= $error ?></div><?php endif; ?>

    <?php if (in_array($action, ['add', 'edit'])): ?>
    <!-- FORMULAIRE PRODUIT -->
    <div class="admin-card">
      <div class="admin-card-header">
        <span class="admin-card-title"><?= $action === 'edit' ? 'Modifier' : 'Nouveau' ?> Produit</span>
      </div>
      <div class="admin-card-body">
        <form method="POST">
          <input type="hidden" name="action" value="<?= $action === 'edit' ? 'save_edit' : 'save_add' ?>">
          <?php if ($action === 'edit' && $editProduct): ?>
          <input type="hidden" name="edit_id" value="<?= $editProduct['id'] ?>">
          <?php endif; ?>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;">
            <div class="form-group">
              <label class="form-label">Nom du parfum *</label>
              <input type="text" name="nom" class="form-control" required placeholder="Chanel N°5"
                     value="<?= htmlspecialchars($editProduct['nom'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Marque *</label>
              <input type="text" name="marque" class="form-control" required placeholder="Chanel"
                     value="<?= htmlspecialchars($editProduct['marque'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Prix (€) *</label>
              <input type="number" name="prix" class="form-control" required min="0" step="0.01" placeholder="149.90"
                     value="<?= $editProduct['prix'] ?? '' ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Prix Promo (€)</label>
              <input type="number" name="prix_promo" class="form-control" min="0" step="0.01" placeholder="Optionnel"
                     value="<?= $editProduct['prix_promo'] ?? '' ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Stock</label>
              <input type="number" name="stock" class="form-control" min="0" placeholder="0"
                     value="<?= $editProduct['stock'] ?? '0' ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Volume</label>
              <input type="text" name="volume" class="form-control" placeholder="100ml"
                     value="<?= htmlspecialchars($editProduct['volume'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Genre</label>
              <select name="genre" class="form-control">
                <option value="femme" <?= ($editProduct['genre'] ?? '') === 'femme' ? 'selected' : '' ?>>Femme</option>
                <option value="homme" <?= ($editProduct['genre'] ?? '') === 'homme' ? 'selected' : '' ?>>Homme</option>
                <option value="mixte" <?= ($editProduct['genre'] ?? 'mixte') === 'mixte' ? 'selected' : '' ?>>Mixte</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Catégorie</label>
              <select name="categorie_id" class="form-control">
                <option value="">-- Aucune --</option>
                <?php foreach ($categories as $c): ?>
                <option value="<?= $c['id'] ?>" <?= ($editProduct['categorie_id'] ?? '') == $c['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($c['nom']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label">Description</label>
              <textarea name="description" class="form-control" rows="4" placeholder="Description du parfum, notes olfactives..."><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>
            </div>
            <?php if ($action === 'edit'): ?>
            <div class="form-group">
              <label class="form-label">Statut</label>
              <select name="statut" class="form-control">
                <option value="actif" <?= ($editProduct['statut'] ?? '') === 'actif' ? 'selected' : '' ?>>Actif</option>
                <option value="inactif" <?= ($editProduct['statut'] ?? '') === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                <option value="rupture" <?= ($editProduct['statut'] ?? '') === 'rupture' ? 'selected' : '' ?>>Rupture</option>
              </select>
            </div>
            <?php endif; ?>
          </div>

          <div style="display:flex;gap:1rem;margin-top:1rem;">
            <button type="submit" class="btn btn-primary">
              <?= $action === 'edit' ? '✓ Mettre à jour' : '+ Ajouter' ?>
            </button>
            <a href="products.php" class="btn btn-dark">Annuler</a>
          </div>
        </form>
      </div>
    </div>

    <?php else: ?>
    <!-- LISTE DES PRODUITS -->
    <div class="admin-card">
      <div class="admin-card-header">
        <span class="admin-card-title">Tous les Produits (<?= count($products) ?>)</span>
        <input type="text" id="searchProd" placeholder="Rechercher..." 
               style="background:var(--gris-moyen);border:1px solid rgba(201,169,110,0.2);color:var(--blanc);padding:0.4rem 0.75rem;font-size:0.8rem;outline:none;" 
               oninput="filterTable(this.value)">
      </div>
      <div style="overflow-x:auto;">
        <table class="admin-table" id="prodTable">
          <thead>
            <tr>
              <th>ID</th><th>Produit</th><th>Marque</th><th>Prix</th>
              <th>Stock</th><th>Genre</th><th>Statut</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $p): ?>
            <tr>
              <td style="color:#888;font-size:0.8rem;">#<?= $p['id'] ?></td>
              <td>
                <div style="font-weight:500;"><?= htmlspecialchars($p['nom']) ?></div>
                <div style="font-size:0.72rem;color:#888;"><?= htmlspecialchars($p['cat_nom'] ?? '') ?></div>
              </td>
              <td style="color:var(--or);"><?= htmlspecialchars($p['marque']) ?></td>
              <td><?= formatPrice($p['prix']) ?></td>
              <td>
                <span style="color:<?= $p['stock'] == 0 ? '#e74c3c' : ($p['stock'] <= 5 ? '#e67e22' : '#2ecc71') ?>">
                  <?= $p['stock'] ?>
                </span>
              </td>
              <td><span style="font-size:0.72rem;color:#888;"><?= ucfirst($p['genre']) ?></span></td>
              <td><span class="badge badge-<?= $p['statut'] ?>"><?= $p['statut'] ?></span></td>
              <td>
                <div style="display:flex;gap:0.5rem;">
                  <a href="?action=edit&id=<?= $p['id'] ?>" class="btn btn-dark btn-sm">✏️ Éditer</a>
                  <?php if ($p['statut'] !== 'inactif'): ?>
                  <a href="?action=delete&id=<?= $p['id'] ?>" class="btn btn-danger btn-sm" 
                     data-confirm="Désactiver <?= htmlspecialchars($p['nom']) ?> ?">🗑️</a>
                  <?php else: ?>
                  <a href="?action=restore&id=<?= $p['id'] ?>" class="btn btn-outline btn-sm">↺</a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </main>
</div>

<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
<script>
function filterTable(q) {
  q = q.toLowerCase();
  document.querySelectorAll('#prodTable tbody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
</script>
</body>
</html>
