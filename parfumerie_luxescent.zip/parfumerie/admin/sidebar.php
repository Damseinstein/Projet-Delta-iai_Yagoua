<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<aside class="admin-sidebar">
  <div class="admin-logo">
    LUXE SCENT
    <small>Administration</small>
  </div>
  
  <nav class="admin-nav">
    <div class="admin-nav-section">Général</div>
    <a href="<?= SITE_URL ?>/admin/" class="admin-nav-item <?= $currentPage === 'index.php' ? 'active' : '' ?>">
      📊 Dashboard
    </a>
    
    <div class="admin-nav-section">Catalogue</div>
    <a href="<?= SITE_URL ?>/admin/products.php" class="admin-nav-item <?= $currentPage === 'products.php' ? 'active' : '' ?>">
      📦 Produits
    </a>
    <a href="<?= SITE_URL ?>/admin/categories.php" class="admin-nav-item <?= $currentPage === 'categories.php' ? 'active' : '' ?>">
      🏷️ Catégories
    </a>
    
    <div class="admin-nav-section">Ventes</div>
    <a href="<?= SITE_URL ?>/admin/orders.php" class="admin-nav-item <?= $currentPage === 'orders.php' ? 'active' : '' ?>">
      🛒 Commandes
    </a>
    <a href="<?= SITE_URL ?>/admin/promos.php" class="admin-nav-item <?= $currentPage === 'promos.php' ? 'active' : '' ?>">
      🎟️ Codes Promo
    </a>
    
    <div class="admin-nav-section">Clients</div>
    <a href="<?= SITE_URL ?>/admin/clients.php" class="admin-nav-item <?= $currentPage === 'clients.php' ? 'active' : '' ?>">
      👥 Clients
    </a>
    
    <div class="admin-nav-section" style="margin-top:2rem;"></div>
    <a href="<?= SITE_URL ?>" class="admin-nav-item" target="_blank">
      🌐 Voir la boutique
    </a>
    <a href="<?= SITE_URL ?>/pages/logout.php" class="admin-nav-item">
      🚪 Déconnexion
    </a>
  </nav>
</aside>
