<?php
require_once '../includes/config.php';
if (!isAdmin()) redirect(SITE_URL . '/pages/login.php');
$pageTitle = 'Commandes - Admin LUXE SCENT';

// Mettre à jour le statut d'une commande
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id = (int)$_POST['order_id'];
    $statut = $_POST['statut'];
    $validStatuts = ['en_attente', 'confirmee', 'expediee', 'livree', 'annulee'];
    if (in_array($statut, $validStatuts)) {
        $pdo->prepare("UPDATE commandes SET statut = ? WHERE id = ?")->execute([$statut, $id]);
        $success = 'Statut mis à jour.';
    }
}

// Détail d'une commande
$detailOrder = null;
$orderLines = [];
if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT c.*, u.prenom, u.nom, u.email FROM commandes c LEFT JOIN utilisateurs u ON c.utilisateur_id = u.id WHERE c.id = ?");
    $stmt->execute([(int)$_GET['id']]);
    $detailOrder = $stmt->fetch();
    if ($detailOrder) {
        $lines = $pdo->prepare("SELECT lc.*, p.nom as prod_nom, p.marque FROM lignes_commande lc LEFT JOIN produits p ON lc.produit_id = p.id WHERE lc.commande_id = ?");
        $lines->execute([$detailOrder['id']]);
        $orderLines = $lines->fetchAll();
    }
}

// Filtres
$statusFilter = $_GET['status'] ?? 'all';
$where = $statusFilter !== 'all' ? "WHERE c.statut = '" . $pdo->quote($statusFilter) . "'" : '';
$orders = $pdo->query("SELECT c.*, u.prenom, u.nom FROM commandes c LEFT JOIN utilisateurs u ON c.utilisateur_id = u.id $where ORDER BY c.date_commande DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
  <?php include 'sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1 class="admin-page-title">Commandes</h1>
      <div style="display:flex;gap:0.5rem;">
        <?php foreach (['all'=>'Toutes','en_attente'=>'En attente','confirmee'=>'Confirmées','expediee'=>'Expédiées','livree'=>'Livrées','annulee'=>'Annulées'] as $val=>$label): ?>
        <a href="?status=<?= $val ?>" class="btn btn-sm <?= $statusFilter === $val ? 'btn-primary' : 'btn-dark' ?>"><?= $label ?></a>
        <?php endforeach; ?>
      </div>
    </div>

    <?php if (isset($success)): ?><div class="alert alert-success">✓ <?= $success ?></div><?php endif; ?>

    <?php if ($detailOrder): ?>
    <!-- DÉTAIL COMMANDE -->
    <div style="margin-bottom:1.5rem;">
      <a href="orders.php" class="btn btn-dark btn-sm">← Retour</a>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;">
      <div class="admin-card">
        <div class="admin-card-header">
          <span class="admin-card-title">Commande <?= $detailOrder['reference'] ?></span>
          <span class="badge badge-<?= $detailOrder['statut'] ?>"><?= str_replace('_',' ',$detailOrder['statut']) ?></span>
        </div>
        <div class="admin-card-body">
          <div style="display:grid;gap:0.75rem;font-size:0.85rem;">
            <div style="display:flex;justify-content:space-between;">
              <span style="color:#888">Client</span>
              <span><?= htmlspecialchars($detailOrder['prenom'].' '.$detailOrder['nom']) ?></span>
            </div>
            <div style="display:flex;justify-content:space-between;">
              <span style="color:#888">Email</span>
              <span><?= htmlspecialchars($detailOrder['email']) ?></span>
            </div>
            <div style="display:flex;justify-content:space-between;">
              <span style="color:#888">Date</span>
              <span><?= date('d/m/Y H:i', strtotime($detailOrder['date_commande'])) ?></span>
            </div>
            <div style="display:flex;justify-content:space-between;">
              <span style="color:#888">Total</span>
              <span style="color:var(--or);font-size:1.1rem;"><?= formatPrice($detailOrder['total']) ?></span>
            </div>
            <div style="display:flex;justify-content:space-between;">
              <span style="color:#888">Paiement</span>
              <span><?= htmlspecialchars($detailOrder['methode_paiement']) ?></span>
            </div>
            <div>
              <div style="color:#888;margin-bottom:0.25rem;">Adresse</div>
              <div style="font-size:0.82rem;"><?= htmlspecialchars($detailOrder['adresse_livraison']) ?></div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="admin-card">
        <div class="admin-card-header"><span class="admin-card-title">Changer le Statut</span></div>
        <div class="admin-card-body">
          <form method="POST">
            <input type="hidden" name="order_id" value="<?= $detailOrder['id'] ?>">
            <div class="form-group">
              <label class="form-label">Nouveau statut</label>
              <select name="statut" class="form-control">
                <?php foreach (['en_attente'=>'En attente','confirmee'=>'Confirmée','expediee'=>'Expédiée','livree'=>'Livrée','annulee'=>'Annulée'] as $val=>$label): ?>
                <option value="<?= $val ?>" <?= $detailOrder['statut'] === $val ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="submit" name="update_status" class="btn btn-primary">Mettre à jour</button>
          </form>
        </div>
      </div>

      <div class="admin-card" style="grid-column:1/-1">
        <div class="admin-card-header"><span class="admin-card-title">Articles commandés</span></div>
        <table class="admin-table">
          <thead><tr><th>Produit</th><th>Marque</th><th>Qté</th><th>Prix unitaire</th><th>Total</th></tr></thead>
          <tbody>
            <?php foreach ($orderLines as $line): ?>
            <tr>
              <td><?= htmlspecialchars($line['prod_nom'] ?? 'Produit supprimé') ?></td>
              <td style="color:var(--or)"><?= htmlspecialchars($line['marque'] ?? '') ?></td>
              <td><?= $line['quantite'] ?></td>
              <td><?= formatPrice($line['prix_unitaire']) ?></td>
              <td style="color:var(--or)"><?= formatPrice($line['quantite'] * $line['prix_unitaire']) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php else: ?>
    <!-- LISTE COMMANDES -->
    <div class="admin-card">
      <div class="admin-card-header">
        <span class="admin-card-title">Toutes les commandes (<?= count($orders) ?>)</span>
      </div>
      <div style="overflow-x:auto;">
        <table class="admin-table">
          <thead>
            <tr><th>Référence</th><th>Client</th><th>Total</th><th>Statut</th><th>Paiement</th><th>Date</th><th>Action</th></tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $o): ?>
            <tr>
              <td style="color:var(--or);font-size:0.8rem;font-weight:500;"><?= $o['reference'] ?></td>
              <td><?= htmlspecialchars($o['prenom'].' '.$o['nom']) ?></td>
              <td style="color:var(--or)"><?= formatPrice($o['total']) ?></td>
              <td><span class="badge badge-<?= $o['statut'] ?>"><?= str_replace('_',' ',$o['statut']) ?></span></td>
              <td style="font-size:0.8rem;color:#888"><?= $o['methode_paiement'] ?></td>
              <td style="font-size:0.8rem;color:#888"><?= date('d/m/Y', strtotime($o['date_commande'])) ?></td>
              <td>
                <a href="?id=<?= $o['id'] ?>" class="btn btn-dark btn-sm">Détails</a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </main>
</div>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
