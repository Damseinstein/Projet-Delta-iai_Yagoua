<?php
require_once 'includes/config.php';

$pageTitle = 'LUXE SCENT - Parfumerie de Luxe';

// Produits vedettes
$featuredProducts = $pdo->query("SELECT p.*, c.nom as categorie_nom FROM produits p LEFT JOIN categories c ON p.categorie_id = c.id WHERE p.statut = 'actif' ORDER BY p.note_moyenne DESC LIMIT 8")->fetchAll();

// Stats
$totalProducts = $pdo->query("SELECT COUNT(*) FROM produits WHERE statut='actif'")->fetchColumn();
$totalBrands = $pdo->query("SELECT COUNT(DISTINCT marque) FROM produits")->fetchColumn();
$totalClients = $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role='client'")->fetchColumn();

// Emojis par genre
function getEmoji($genre) {
    $emojis = ['femme' => '🌸', 'homme' => '🌿', 'mixte' => '✨'];
    return $emojis[$genre] ?? '🌺';
}

include 'includes/header.php';
?>

<!-- HERO -->
<section class="hero">
  <div class="hero-content">
    <div class="hero-tag fade-in">Collection 2024</div>
    <h1 class="hero-title fade-in-delay-1">
      L'Art du<br>
      <em>Parfum</em><br>
      Révélé
    </h1>
    <p class="hero-desc fade-in-delay-2">
      Explorez notre collection exclusive de parfums de prestige. 
      Des fragrances d'exception sélectionnées par nos experts pour capturer 
      l'essence de votre personnalité.
    </p>
    <div class="hero-actions fade-in-delay-3">
      <a href="pages/catalogue.php" class="btn btn-primary">Explorer la Collection</a>
      <a href="pages/catalogue.php?cat=3" class="btn btn-outline">Prestige</a>
    </div>
  </div>
  <div class="hero-visual">
    <div class="hero-ornament">✦</div>
    <div class="hero-stats">
      <div class="stat-item">
        <span class="stat-num"><?= $totalProducts ?>+</span>
        <span class="stat-label">Fragrances</span>
      </div>
      <div class="stat-item">
        <span class="stat-num"><?= $totalBrands ?>+</span>
        <span class="stat-label">Maisons</span>
      </div>
      <div class="stat-item">
        <span class="stat-num"><?= number_format($totalClients) ?>+</span>
        <span class="stat-label">Clients</span>
      </div>
    </div>
  </div>
</section>

<!-- CATEGORIES RAPIDES -->
<section style="background:var(--gris-fonce);padding:3rem 6rem;border-top:1px solid rgba(201,169,110,0.1);border-bottom:1px solid rgba(201,169,110,0.1);">
  <div style="display:flex;justify-content:center;gap:3rem;flex-wrap:wrap;">
    <a href="pages/catalogue.php?genre=femme" style="text-decoration:none;text-align:center;transition:all 0.3s;" 
       onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
      <div style="font-size:3rem;margin-bottom:0.5rem;">🌸</div>
      <div class="subtitle">Pour Elle</div>
    </a>
    <a href="pages/catalogue.php?genre=homme" style="text-decoration:none;text-align:center;transition:all 0.3s;"
       onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
      <div style="font-size:3rem;margin-bottom:0.5rem;">🌿</div>
      <div class="subtitle">Pour Lui</div>
    </a>
    <a href="pages/catalogue.php?genre=mixte" style="text-decoration:none;text-align:center;transition:all 0.3s;"
       onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
      <div style="font-size:3rem;margin-bottom:0.5rem;">✨</div>
      <div class="subtitle">Mixte</div>
    </a>
    <a href="pages/catalogue.php?cat=3" style="text-decoration:none;text-align:center;transition:all 0.3s;"
       onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
      <div style="font-size:3rem;margin-bottom:0.5rem;">👑</div>
      <div class="subtitle">Prestige</div>
    </a>
    <a href="pages/catalogue.php?cat=5" style="text-decoration:none;text-align:center;transition:all 0.3s;"
       onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
      <div style="font-size:3rem;margin-bottom:0.5rem;">🎁</div>
      <div class="subtitle">Coffrets</div>
    </a>
  </div>
</section>

<!-- BEST-SELLERS -->
<section class="section">
  <div class="section-header">
    <span class="subtitle">Sélection d'Experts</span>
    <h2 class="section-title">Nos Best-Sellers</h2>
    <div class="section-divider"></div>
  </div>

  <div class="products-grid">
    <?php foreach ($featuredProducts as $p): 
      $emoji = getEmoji($p['genre']);
      $stars = str_repeat('★', round($p['note_moyenne'])) . str_repeat('☆', 5 - round($p['note_moyenne']));
    ?>
    <div class="product-card" 
         data-genre="<?= $p['genre'] ?>" 
         data-name="<?= htmlspecialchars($p['nom']) ?>"
         data-brand="<?= htmlspecialchars($p['marque']) ?>">
      <div class="product-image">
        <?php if ($p['note_moyenne'] >= 4.8): ?>
          <span class="product-badge">★ Best-Seller</span>
        <?php endif; ?>
        <span class="product-emoji"><?= $emoji ?></span>
        <div class="product-actions">
          <a href="pages/product.php?id=<?= $p['id'] ?>" class="btn btn-outline btn-sm">Voir</a>
          <button class="btn btn-primary btn-sm btn-add-cart" data-id="<?= $p['id'] ?>">+ Panier</button>
        </div>
      </div>
      <div class="product-info">
        <div class="product-brand"><?= htmlspecialchars($p['marque']) ?></div>
        <div class="product-name"><?= htmlspecialchars($p['nom']) ?></div>
        <div class="product-stars">
          <?= $stars ?>
          <span>(<?= $p['nb_avis'] ?>)</span>
        </div>
        <div class="product-footer">
          <div>
            <span class="product-price"><?= formatPrice($p['prix']) ?></span>
            <?php if ($p['prix_promo']): ?>
              <span class="product-price-old"><?= formatPrice($p['prix_promo']) ?></span>
            <?php endif; ?>
          </div>
          <button class="btn-add-cart" data-id="<?= $p['id'] ?>">+ Panier</button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="text-center mt-4">
    <a href="pages/catalogue.php" class="btn btn-outline">Voir toute la collection →</a>
  </div>
</section>

<!-- BANNIERE PROMO -->
<section style="background:linear-gradient(135deg, var(--gris-fonce) 0%, rgba(201,169,110,0.08) 100%);padding:5rem 6rem;text-align:center;border-top:1px solid rgba(201,169,110,0.15);border-bottom:1px solid rgba(201,169,110,0.15);">
  <div class="subtitle" style="margin-bottom:1rem;">Offre Exclusive</div>
  <h2 style="font-family:'Cormorant Garamond',serif;font-size:clamp(2rem,4vw,3.5rem);font-weight:300;color:var(--blanc);margin-bottom:1rem;">
    Utilisez le code <span style="color:var(--or);font-style:italic;">BIENVENUE10</span>
  </h2>
  <p style="color:#888;font-size:0.9rem;margin-bottom:2rem;">10% de réduction sur votre première commande</p>
  <a href="pages/catalogue.php" class="btn btn-primary">Profiter de l'offre</a>
</section>

<!-- AVANTAGES -->
<section class="section">
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;text-align:center;">
    <?php 
    $avantages = [
      ['🚚', 'Livraison Gratuite', 'À partir de 80€ d\'achat'],
      ['🔒', 'Paiement Sécurisé', 'SSL & 3D Secure'],
      ['↩️', 'Retour 30 jours', 'Satisfait ou remboursé'],
      ['💬', 'Support 7j/7', 'Experts à votre service'],
    ];
    foreach ($avantages as $a):
    ?>
    <div style="padding:2rem;background:var(--gris-fonce);border:1px solid rgba(201,169,110,0.08);">
      <div style="font-size:2.5rem;margin-bottom:1rem;"><?= $a[0] ?></div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:1.2rem;color:var(--blanc);margin-bottom:0.5rem;"><?= $a[1] ?></div>
      <div style="font-size:0.78rem;color:#888;"><?= $a[2] ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
