<!-- FOOTER -->
<footer class="footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <h3>LUXE SCENT</h3>
      <p>Découvrez l'art de la parfumerie de luxe. Des fragrances d'exception soigneusement sélectionnées pour sublimer votre identité olfactive.</p>
    </div>
    <div class="footer-col">
      <h4>Collection</h4>
      <ul>
        <li><a href="<?= SITE_URL ?>/pages/catalogue.php?genre=femme">Pour Elle</a></li>
        <li><a href="<?= SITE_URL ?>/pages/catalogue.php?genre=homme">Pour Lui</a></li>
        <li><a href="<?= SITE_URL ?>/pages/catalogue.php?genre=mixte">Mixte</a></li>
        <li><a href="<?= SITE_URL ?>/pages/catalogue.php">Tout Voir</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Service</h4>
      <ul>
        <li><a href="#">Livraison</a></li>
        <li><a href="#">Retours</a></li>
        <li><a href="#">FAQ</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Mon Compte</h4>
      <ul>
        <?php if (isLoggedIn()): ?>
          <li><a href="<?= SITE_URL ?>/pages/account.php">Mon Profil</a></li>
          <li><a href="<?= SITE_URL ?>/pages/orders.php">Mes Commandes</a></li>
          <li><a href="<?= SITE_URL ?>/pages/logout.php">Déconnexion</a></li>
        <?php else: ?>
          <li><a href="<?= SITE_URL ?>/pages/login.php">Connexion</a></li>
          <li><a href="<?= SITE_URL ?>/pages/register.php">Inscription</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© <?= date('Y') ?> Luxe Scent. Tous droits réservés.</span>
    <span style="color:var(--or);font-size:0.7rem;letter-spacing:0.2em">PARFUMERIE DE LUXE</span>
  </div>
</footer>

<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
