<?php
if (!isset($pdo)) {
    require_once __DIR__ . '/config.php';
}
$pageTitle = $pageTitle ?? 'LUXE SCENT - Parfumerie de Luxe';

// Compter les articles dans le panier
$cartCount = 0;
if (isLoggedIn()) {
    $stmt = $pdo->prepare("SELECT SUM(quantite) FROM panier WHERE utilisateur_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $cartCount = (int)$stmt->fetchColumn();
}

// Récupérer les catégories pour la nav
$categories = $pdo->query("SELECT * FROM categories ORDER BY nom")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
  <style>
    .header { padding-top: 0; }
  </style>
</head>
<body>

<!-- HEADER -->
<header class="header">
  <a href="<?= SITE_URL ?>" class="header-logo">
    LS
    <span>Luxe Scent</span>
  </a>

  <nav>
    <ul class="nav">
      <li><a href="<?= SITE_URL ?>">Accueil</a></li>
      <li><a href="<?= SITE_URL ?>/pages/catalogue.php">Collection</a></li>
      <li><a href="<?= SITE_URL ?>/pages/catalogue.php?genre=homme">Homme</a></li>
      <li><a href="<?= SITE_URL ?>/pages/catalogue.php?genre=femme">Femme</a></li>
      <li><a href="<?= SITE_URL ?>/pages/catalogue.php?genre=mixte">Mixte</a></li>
    </ul>
  </nav>

  <div class="header-actions">
    <?php if (isLoggedIn()): ?>
      <?php if (isAdmin()): ?>
        <a href="<?= SITE_URL ?>/admin/" class="btn btn-outline btn-sm">Admin</a>
      <?php endif; ?>
      <a href="<?= SITE_URL ?>/pages/account.php" class="btn btn-dark btn-sm">
        👤 <?= htmlspecialchars($_SESSION['prenom'] ?? 'Compte') ?>
      </a>
    <?php else: ?>
      <a href="<?= SITE_URL ?>/pages/login.php" class="btn btn-dark btn-sm">Connexion</a>
    <?php endif; ?>
    <a href="#" id="cartBtn" class="btn-cart">
      🛍️
      <span class="cart-count"><?= $cartCount ?></span>
    </a>
  </div>
</header>

<!-- CART SIDEBAR -->
<div class="overlay-bg" id="overlayBg"></div>
<div class="cart-sidebar" id="cartSidebar">
  <div class="cart-header">
    <h2>Votre Panier</h2>
    <button class="modal-close" id="cartClose">✕</button>
  </div>
  <div class="cart-items" id="cartItems">
    <div style="text-align:center;color:#888;padding:3rem 1rem;">
      <p style="font-family:'Cormorant Garamond',serif;font-size:1.3rem">Votre panier est vide</p>
      <p style="font-size:0.8rem;margin-top:0.5rem">Explorez notre collection</p>
    </div>
  </div>
  <div class="cart-footer">
    <div class="cart-total">
      <span class="cart-total-label">Total</span>
      <span class="cart-total-price" id="cartTotal">0,00 €</span>
    </div>
    <a href="<?= SITE_URL ?>/pages/checkout.php" class="btn btn-primary w-100">Commander</a>
    <?php if (!isLoggedIn()): ?>
    <p style="text-align:center;font-size:0.75rem;color:#888;margin-top:0.75rem">
      <a href="<?= SITE_URL ?>/pages/login.php" style="color:var(--or)">Connectez-vous</a> pour sauvegarder votre panier
    </p>
    <?php endif; ?>
  </div>
</div>
<!-- /CART SIDEBAR -->
