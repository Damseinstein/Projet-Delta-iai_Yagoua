<?php
// ============================================================
// Configuration de la base de données - WampServer
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'parfumerie_db');
define('SITE_NAME', 'LUXE SCENT');
define('SITE_URL', 'http://localhost/parfumerie');
define('ADMIN_EMAIL', 'admin@luxescent.fr');

// Connexion PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die(json_encode(['error' => 'Connexion échouée: ' . $e->getMessage()]));
}

// Démarrage de session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fonctions utilitaires
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function formatPrice($price) {
    return number_format($price, 2, ',', ' ') . ' €';
}

function generateRef() {
    return 'CMD-' . strtoupper(substr(md5(uniqid()), 0, 8));
}
?>
