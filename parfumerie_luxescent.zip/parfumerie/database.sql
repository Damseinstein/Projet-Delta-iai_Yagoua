-- ============================================================
-- ANALYSE MERISE - MODÈLE LOGIQUE DE DONNÉES (MLD)
-- Application de Gestion de Parfumerie "LUXE SCENT"
-- Base de données : parfumerie_db
-- ============================================================

-- ENTITÉS IDENTIFIÉES (MCD) :
-- PRODUIT (id, nom, marque, description, prix, stock, image, categorie_id, statut)
-- CATEGORIE (id, nom, description)
-- UTILISATEUR (id, nom, prenom, email, mot_de_passe, role, date_inscription)
-- COMMANDE (id, utilisateur_id, date_commande, total, statut, adresse_livraison)
-- LIGNE_COMMANDE (id, commande_id, produit_id, quantite, prix_unitaire)
-- AVIS (id, produit_id, utilisateur_id, note, commentaire, date)
-- PANIER (id, utilisateur_id, produit_id, quantite)
-- PROMO (id, code, reduction, date_debut, date_fin, actif)

-- ASSOCIATIONS (MCD) :
-- PRODUIT appartient à CATEGORIE (N:1)
-- COMMANDE passée par UTILISATEUR (N:1)
-- COMMANDE contient PRODUIT via LIGNE_COMMANDE (N:M)
-- UTILISATEUR donne AVIS sur PRODUIT (N:M)
-- UTILISATEUR a PANIER contenant PRODUIT (N:M)

CREATE DATABASE IF NOT EXISTS parfumerie_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE parfumerie_db;

-- TABLE : categories
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- TABLE : utilisateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    role ENUM('admin','client') DEFAULT 'client',
    telephone VARCHAR(20),
    adresse TEXT,
    date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    actif TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- TABLE : produits
CREATE TABLE IF NOT EXISTS produits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    marque VARCHAR(100) NOT NULL,
    description TEXT,
    prix DECIMAL(10,2) NOT NULL,
    prix_promo DECIMAL(10,2) DEFAULT NULL,
    stock INT DEFAULT 0,
    volume VARCHAR(50),
    image VARCHAR(255) DEFAULT 'default.jpg',
    categorie_id INT,
    genre ENUM('homme','femme','mixte') DEFAULT 'mixte',
    note_moyenne DECIMAL(3,2) DEFAULT 0,
    nb_avis INT DEFAULT 0,
    statut ENUM('actif','inactif','rupture') DEFAULT 'actif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categorie_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- TABLE : commandes
CREATE TABLE IF NOT EXISTS commandes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT,
    reference VARCHAR(20) NOT NULL UNIQUE,
    date_commande TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10,2) NOT NULL,
    statut ENUM('en_attente','confirmee','expediee','livree','annulee') DEFAULT 'en_attente',
    adresse_livraison TEXT,
    methode_paiement VARCHAR(50) DEFAULT 'carte',
    notes TEXT,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- TABLE : lignes_commande (table associative COMMANDE-PRODUIT)
CREATE TABLE IF NOT EXISTS lignes_commande (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commande_id INT NOT NULL,
    produit_id INT,
    quantite INT NOT NULL DEFAULT 1,
    prix_unitaire DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE,
    FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- TABLE : panier
CREATE TABLE IF NOT EXISTS panier (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    produit_id INT NOT NULL,
    quantite INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE,
    UNIQUE KEY unique_panier (utilisateur_id, produit_id)
) ENGINE=InnoDB;

-- TABLE : avis
CREATE TABLE IF NOT EXISTS avis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produit_id INT NOT NULL,
    utilisateur_id INT NOT NULL,
    note INT NOT NULL CHECK (note BETWEEN 1 AND 5),
    commentaire TEXT,
    date_avis TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- TABLE : codes_promo
CREATE TABLE IF NOT EXISTS codes_promo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    reduction DECIMAL(5,2) NOT NULL,
    type_reduction ENUM('pourcentage','montant') DEFAULT 'pourcentage',
    date_debut DATE,
    date_fin DATE,
    utilisation_max INT DEFAULT 100,
    utilisation_actuelle INT DEFAULT 0,
    actif TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- ============================================================
-- DONNÉES DE DÉMONSTRATION
-- ============================================================

-- Catégories
INSERT INTO categories (nom, description) VALUES
('Eau de Parfum', 'Concentration élevée, tenue longue durée'),
('Eau de Toilette', 'Fragrance légère et fraîche'),
('Parfum Pur', 'Concentration maximale, luxe absolu'),
('Collections Prestige', 'Éditions limitées et collections exclusives'),
('Coffrets Cadeaux', 'Idées cadeaux et sets découverte');

-- Compte administrateur (mot de passe: Admin2024!)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role) VALUES
('Dupont', 'Admin', 'admin@luxescent.fr', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Compte client test (mot de passe: Client123!)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, telephone) VALUES
('Martin', 'Sophie', 'sophie.martin@email.fr', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'client', '0612345678');

-- Produits
INSERT INTO produits (nom, marque, description, prix, stock, volume, categorie_id, genre, note_moyenne, nb_avis) VALUES
('Chanel N°5', 'Chanel', 'Le parfum iconique par excellence. Une composition florale aldéhydée intemporelle créée par Ernest Beaux en 1921. Notes de tête : Ylang-Ylang, Néroli. Notes de cœur : Rose, Jasmin. Notes de fond : Vétiver, Santal, Musc.', 149.90, 25, '50ml', 1, 'femme', 4.8, 342),
('Sauvage', 'Dior', 'Un parfum d\'une fraîcheur sauvage et noble, inspiré par les grands espaces. Notes de tête : Bergamote de Calabre. Notes de cœur : Poivre Sichuan, Lavande. Notes de fond : Ambroxan, Cèdre, Labdanum.', 129.00, 40, '100ml', 2, 'homme', 4.9, 521),
('Black Opium', 'Yves Saint Laurent', 'Un parfum féminin addictif et audacieux. Un cocktail de café noir, de fleur blanche et de vanille. Intense, sensuel et rock\'n\'roll.', 119.00, 30, '50ml', 1, 'femme', 4.7, 289),
('Bleu de Chanel', 'Chanel', 'Un bois aromatique sensoriel et déterminé. Un parfum qui exprime la liberté d\'un homme qui refuse toute convention.', 139.00, 35, '100ml', 1, 'homme', 4.8, 412),
('La Vie Est Belle', 'Lancôme', 'Un parfum qui célèbre la liberté de choisir son propre bonheur. Une iris gourmande et lumineuse au cœur de fleurs blanches.', 109.00, 20, '50ml', 1, 'femme', 4.6, 198),
('Acqua di Gio', 'Giorgio Armani', 'L\'essence de la Méditerranée. Un parfum aquatique, frais et naturel qui capture l\'esprit de la mer.', 98.00, 45, '100ml', 2, 'homme', 4.7, 367),
('Coco Mademoiselle', 'Chanel', 'Un parfum oriental frais, moderne et vibrant. L\'esprit libre et la sensualité de la femme Chanel contemporaine.', 155.00, 15, '50ml', 3, 'femme', 4.9, 445),
('J\'adore', 'Dior', 'Un hymne à la femme, à sa beauté et à sa sensualité. Un bouquet floral de Ylang-Ylang, Rose Damascena et Jasmin Sambac.', 135.00, 28, '100ml', 1, 'femme', 4.8, 312),
('Oud Wood', 'Tom Ford', 'Un parfum de luxe, rare et précieux. Le bois de oud rare associé à la rose de Damas et au santal crémeux.', 285.00, 10, '50ml', 3, 'mixte', 4.9, 156),
('Flowerbomb', 'Viktor & Rolf', 'Une explosion florale qui illumine la vie. Un cocktail de jasmin, de rose, d\'orchidée et de freesia sur un fond de patchouli.', 125.00, 22, '50ml', 1, 'femme', 4.7, 234),
('Explorer', 'Montblanc', 'L\'esprit d\'aventure. Un parfum boisé et cuiré pour l\'homme moderne et audacieux.', 79.00, 50, '100ml', 2, 'homme', 4.5, 178),
('Good Girl', 'Carolina Herrera', 'Un parfum aux deux facettes : le bien et le mal. Un parfum jasmin intense posé sur un fond de Tonka bean sombre et chocolaté.', 112.00, 18, '50ml', 1, 'femme', 4.8, 267);

-- Codes promo
INSERT INTO codes_promo (code, reduction, type_reduction, date_debut, date_fin) VALUES
('BIENVENUE10', 10.00, 'pourcentage', '2024-01-01', '2025-12-31'),
('ETE2024', 15.00, 'pourcentage', '2024-06-01', '2024-08-31'),
('LUXE20', 20.00, 'montant', '2024-01-01', '2025-12-31');
