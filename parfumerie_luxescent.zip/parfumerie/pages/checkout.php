<?php
require_once '../includes/config.php';

if (!isLoggedIn()) redirect(SITE_URL . '/pages/login.php');

$pageTitle = 'Commander - LUXE SCENT';

// Récupérer le panier
$stmt = $pdo->prepare("
    SELECT p.id as produit_id, p.nom, p.marque, p.prix, p.genre, p.stock, pa.quantite
    FROM panier pa 
    JOIN produits p ON pa.produit_id = p.id 
    WHERE pa.utilisateur_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$cartItems = $stmt->fetchAll();

if (empty($cartItems)) redirect(SITE_URL);

// Calculer le total
$subtotal = array_sum(array_map(fn($i) => $i['prix'] * $i['quantite'], $cartItems));
$shipping = $subtotal >= 80 ? 0 : 5.99;
$discount = 0;
$promoMessage = '';
$promoCode = '';

// Code promo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_promo'])) {
    $code = strtoupper(trim($_POST['promo_code']));
    $stmt = $pdo->prepare("SELECT * FROM codes_promo WHERE code = ? AND actif = 1 AND (date_fin IS NULL OR date_fin >= CURDATE())");
    $stmt->execute([$code]);
    $promo = $stmt->fetch();
    if ($promo) {
        $_SESSION['promo'] = $promo;
        $promoMessage = "Code <strong>$code</strong> appliqué !";
    } else {
        unset($_SESSION['promo']);
        $promoMessage = "Code invalide ou expiré.";
    }
}

if (isset($_SESSION['promo'])) {
    $promo = $_SESSION['promo'];
    $promoCode = $promo['code'];
    if ($promo['type_reduction'] === 'pourcentage') {
        $discount = $subtotal * ($promo['reduction'] / 100);
    } else {
        $discount = min($promo['reduction'], $subtotal);
    }
}

$total = $subtotal + $shipping - $discount;

// Valider la commande
$orderSuccess = false;
$orderRef = '';
$orderError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $address = sanitize($_POST['address'] ?? '');
    $city = sanitize($_POST['city'] ?? '');
    $postal = sanitize($_POST['postal'] ?? '');
    $payment = sanitize($_POST['payment'] ?? 'carte');

    if (!$address || !$city || !$postal) {
        $orderError = 'Veuillez remplir tous les champs de livraison.';
    } else {
        $fullAddress = "$address, $postal $city";
        $ref = generateRef();
        
        try {
            $pdo->beginTransaction();
            
            // Créer la commande
            $stmt = $pdo->prepare("INSERT INTO commandes (utilisateur_id, reference, total, adresse_livraison, methode_paiement) VALUES (?,?,?,?,?)");
            $stmt->execute([$_SESSION['user_id'], $ref, $total, $fullAddress, $payment]);
            $orderId = $pdo->lastInsertId();
            
            // Créer les lignes de commande
            $insLine = $pdo->prepare("INSERT INTO lignes_commande (commande_id, produit_id, quantite, prix_unitaire) VALUES (?,?,?,?)");
            foreach ($cartItems as $item) {
                $insLine->execute([$orderId, $item['produit_id'], $item['quantite'], $item['prix']]);
                // Décrémenter le stock
                $pdo->prepare("UPDATE produits SET stock = stock - ? WHERE id = ?")->execute([$item['quantite'], $item['produit_id']]);
            }
            
            // Vider le panier
            $pdo->prepare("DELETE FROM panier WHERE utilisateur_id = ?")->execute([$_SESSION['user_id']]);
            
            // Mettre à jour code promo
            if (isset($_SESSION['promo'])) {
                $pdo->prepare("UPDATE codes_promo SET utilisation_actuelle = utilisation_actuelle + 1 WHERE code = ?")->execute([$_SESSION['promo']['code']]);
                unset($_SESSION['promo']);
            }
            
            $pdo->commit();
            $orderSuccess = true;
            $orderRef = $ref;
        } catch (Exception $e) {
            $pdo->rollBack();
            $orderError = 'Erreur lors de la commande. Veuillez réessayer.';
        }
    }
}

// Récupérer les infos utilisateur
$userInfo = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$userInfo->execute([$_SESSION['user_id']]);
$user = $userInfo->fetch();

$emojis = ['femme' => '🌸', 'homme' => '🌿', 'mixte' => '✨'];

include '../includes/header.php';
?>

<main style="padding-top:90px;min-height:100vh;">
  
  <?php if ($orderSuccess): ?>
  <!-- CONFIRMATION COMMANDE -->
  <div style="max-width:600px;margin:5rem auto;text-align:center;padding:0 2rem;">
    <div style="font-size:5rem;margin-bottom:2rem;">✅</div>
    <h1 style="font-family:'Cormorant Garamond',serif;font-size:3rem;font-weight:300;color:var(--or);">Commande Confirmée</h1>
    <p style="color:#888;margin-top:1rem;margin-bottom:2rem;">
      Merci pour votre commande ! Vous recevrez une confirmation par email.
    </p>
    <div style="background:var(--gris-fonce);border:1px solid rgba(201,169,110,0.2);padding:2rem;margin-bottom:2rem;">
      <div class="subtitle" style="margin-bottom:0.5rem;">Référence</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:2rem;color:var(--or);"><?= $orderRef ?></div>
    </div>
    <a href="<?= SITE_URL ?>" class="btn btn-primary">Retour à la boutique</a>
    <a href="<?= SITE_URL ?>/pages/orders.php" class="btn btn-outline" style="margin-left:1rem;">Mes commandes</a>
  </div>

  <?php else: ?>
  
  <div style="max-width:1200px;margin:0 auto;padding:2rem 2rem 5rem;">
    <h1 style="font-family:'Cormorant Garamond',serif;font-size:2.5rem;font-weight:300;margin-bottom:2.5rem;">
      Finaliser la commande
    </h1>

    <?php if ($orderError): ?>
    <div class="alert alert-error"><?= $orderError ?></div>
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 380px;gap:3rem;">
      <!-- FORMULAIRE -->
      <div>
        <form method="POST" id="checkoutForm">
          
          <!-- Adresse livraison -->
          <div class="admin-card" style="margin-bottom:1.5rem;">
            <div class="admin-card-header">
              <span class="admin-card-title">📦 Adresse de Livraison</span>
            </div>
            <div class="admin-card-body">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div>
                  <label class="form-label">Prénom</label>
                  <input type="text" class="form-control" value="<?= htmlspecialchars($user['prenom']) ?>" readonly style="opacity:0.7">
                </div>
                <div>
                  <label class="form-label">Nom</label>
                  <input type="text" class="form-control" value="<?= htmlspecialchars($user['nom']) ?>" readonly style="opacity:0.7">
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Adresse</label>
                <input type="text" name="address" class="form-control" placeholder="15 rue du Faubourg Saint-Honoré" 
                       value="<?= htmlspecialchars($user['adresse'] ?? '') ?>" required>
              </div>
              <div style="display:grid;grid-template-columns:1fr 2fr;gap:1rem;">
                <div class="form-group">
                  <label class="form-label">Code Postal</label>
                  <input type="text" name="postal" class="form-control" placeholder="75008" required>
                </div>
                <div class="form-group">
                  <label class="form-label">Ville</label>
                  <input type="text" name="city" class="form-control" placeholder="Paris" required>
                </div>
              </div>
            </div>
          </div>

          <!-- Mode de paiement -->
          <div class="admin-card">
            <div class="admin-card-header">
              <span class="admin-card-title">💳 Paiement</span>
            </div>
            <div class="admin-card-body">
              <div style="display:grid;gap:0.75rem;">
                <?php foreach ([
                  ['carte', '💳', 'Carte Bancaire', 'Visa, Mastercard, CB'],
                  ['paypal', '🅿️', 'PayPal', 'Paiement sécurisé'],
                  ['virement', '🏦', 'Virement', 'Sous 3 jours ouvrés'],
                ] as [$val, $ico, $label, $desc]): ?>
                <label style="display:flex;align-items:center;gap:1rem;padding:1rem;background:var(--gris-moyen);border:1px solid rgba(201,169,110,0.1);cursor:pointer;transition:all 0.2s;" 
                       onmouseover="this.style.borderColor='rgba(201,169,110,0.4)'" 
                       onmouseout="this.style.borderColor='rgba(201,169,110,0.1)'">
                  <input type="radio" name="payment" value="<?= $val ?>" <?= $val === 'carte' ? 'checked' : '' ?> style="accent-color:var(--or);">
                  <span style="font-size:1.5rem;"><?= $ico ?></span>
                  <div>
                    <div style="font-size:0.9rem;color:var(--blanc);"><?= $label ?></div>
                    <div style="font-size:0.75rem;color:#888;"><?= $desc ?></div>
                  </div>
                </label>
                <?php endforeach; ?>
              </div>
              
              <div style="margin-top:1.5rem;padding:1rem;background:rgba(201,169,110,0.05);border:1px solid rgba(201,169,110,0.15);font-size:0.78rem;color:#888;">
                🔒 Paiement simulé — Application de démonstration
              </div>
            </div>
          </div>

          <button type="submit" name="place_order" class="btn btn-primary" style="margin-top:1.5rem;padding:1rem 3rem;width:100%;justify-content:center;font-size:0.85rem;">
            ✓ Confirmer la commande — <?= formatPrice($total) ?>
          </button>
        </form>
      </div>

      <!-- RÉSUMÉ COMMANDE -->
      <div>
        <div class="admin-card" style="position:sticky;top:90px;">
          <div class="admin-card-header">
            <span class="admin-card-title">Récapitulatif</span>
          </div>
          <div class="admin-card-body" style="padding:1rem 1.5rem;">
            <?php foreach ($cartItems as $item): ?>
            <div style="display:flex;gap:0.75rem;align-items:center;padding:0.75rem 0;border-bottom:1px solid rgba(255,255,255,0.05);">
              <div style="font-size:2rem;"><?= $emojis[$item['genre']] ?? '🌺' ?></div>
              <div style="flex:1;">
                <div style="font-size:0.82rem;color:var(--blanc);"><?= htmlspecialchars($item['nom']) ?></div>
                <div style="font-size:0.7rem;color:#888;">x<?= $item['quantite'] ?></div>
              </div>
              <div style="color:var(--or);font-size:0.9rem;"><?= formatPrice($item['prix'] * $item['quantite']) ?></div>
            </div>
            <?php endforeach; ?>

            <!-- Code promo -->
            <form method="POST" style="margin-top:1rem;">
              <div style="display:flex;gap:0.5rem;">
                <input type="text" name="promo_code" class="form-control" placeholder="Code promo" 
                       value="<?= htmlspecialchars($promoCode) ?>"
                       style="font-size:0.8rem;padding:0.6rem 0.8rem;">
                <button type="submit" name="apply_promo" class="btn btn-outline btn-sm">OK</button>
              </div>
              <?php if ($promoMessage): ?>
              <p style="font-size:0.75rem;color:<?= strpos($promoMessage, 'invalid') !== false ? 'var(--rouge-erreur)' : 'var(--vert-succes)' ?>;margin-top:0.4rem;"><?= $promoMessage ?></p>
              <?php endif; ?>
            </form>

            <!-- Totaux -->
            <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid rgba(201,169,110,0.15);">
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;color:#888;margin-bottom:0.5rem;">
                <span>Sous-total</span><span><?= formatPrice($subtotal) ?></span>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;color:#888;margin-bottom:0.5rem;">
                <span>Livraison</span>
                <span><?= $shipping > 0 ? formatPrice($shipping) : '<span style="color:var(--vert-succes)">Gratuite</span>' ?></span>
              </div>
              <?php if ($discount > 0): ?>
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;color:var(--vert-succes);margin-bottom:0.5rem;">
                <span>Réduction (<?= $promoCode ?>)</span><span>−<?= formatPrice($discount) ?></span>
              </div>
              <?php endif; ?>
              <div style="display:flex;justify-content:space-between;margin-top:0.75rem;padding-top:0.75rem;border-top:1px solid rgba(201,169,110,0.2);">
                <span style="font-family:'Cormorant Garamond',serif;font-size:1.1rem;">Total</span>
                <span style="font-family:'Cormorant Garamond',serif;font-size:1.4rem;color:var(--or);"><?= formatPrice($total) ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</main>

<?php include '../includes/footer.php'; ?>
