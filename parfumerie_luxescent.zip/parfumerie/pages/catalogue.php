<?php
require_once '../includes/config.php';
$pageTitle = 'Collection - LUXE SCENT';

// Filtres
$genre = $_GET['genre'] ?? 'all';
$cat = $_GET['cat'] ?? 0;
$sort = $_GET['sort'] ?? 'popular';
$search = $_GET['q'] ?? '';
$min_price = $_GET['min'] ?? 0;
$max_price = $_GET['max'] ?? 999;

// Construire la requête
$where = ["p.statut = 'actif'"];
$params = [];

if ($genre !== 'all') { $where[] = "p.genre = ?"; $params[] = $genre; }
if ($cat > 0) { $where[] = "p.categorie_id = ?"; $params[] = $cat; }
if ($search) { $where[] = "(p.nom LIKE ? OR p.marque LIKE ? OR p.description LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($min_price > 0) { $where[] = "p.prix >= ?"; $params[] = $min_price; }
if ($max_price < 999) { $where[] = "p.prix <= ?"; $params[] = $max_price; }

$orderBy = match($sort) {
    'price_asc' => 'p.prix ASC',
    'price_desc' => 'p.prix DESC',
    'newest' => 'p.created_at DESC',
    'rating' => 'p.note_moyenne DESC',
    default => 'p.nb_avis DESC'
};

$sql = "SELECT p.*, c.nom as cat_nom FROM produits p 
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE " . implode(' AND ', $where) . " ORDER BY $orderBy";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY nom")->fetchAll();

function getEmoji($genre) {
    $emojis = ['femme' => '🌸', 'homme' => '🌿', 'mixte' => '✨'];
    return $emojis[$genre] ?? '🌺';
}

include '../includes/header.php';
?>

<main style="padding-top:90px;">
  <!-- Page Header -->
  <div style="padding:3rem 6rem 2rem;border-bottom:1px solid rgba(201,169,110,0.1);background:var(--gris-fonce);">
    <span class="subtitle">Notre Sélection</span>
    <h1 style="font-family:'Cormorant Garamond',serif;font-size:3rem;font-weight:300;color:var(--blanc);margin-top:0.5rem;">
      <?php if ($genre !== 'all'): ?>
        Collection <?= ucfirst($genre) ?>
      <?php elseif ($search): ?>
        Résultats pour "<?= htmlspecialchars($search) ?>"
      <?php else: ?>
        Toute la Collection
      <?php endif; ?>
    </h1>
    <p style="color:#888;font-size:0.85rem;margin-top:0.5rem;"><?= count($products) ?> fragrance(s) trouvée(s)</p>
  </div>

  <div style="display:grid;grid-template-columns:280px 1fr;gap:0;min-height:calc(100vh - 200px);">
    
    <!-- SIDEBAR FILTRES -->
    <aside style="background:var(--noir-soft);border-right:1px solid rgba(201,169,110,0.1);padding:2rem;position:sticky;top:70px;height:calc(100vh - 70px);overflow-y:auto;">
      <form method="GET" id="filterForm">
        
        <!-- Recherche -->
        <div style="margin-bottom:2rem;">
          <div class="subtitle" style="margin-bottom:0.75rem;">Recherche</div>
          <div style="display:flex;background:var(--gris-fonce);border:1px solid rgba(201,169,110,0.2);padding:0.6rem 0.75rem;gap:0.5rem;">
            <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Chercher..." 
                   style="background:transparent;border:none;outline:none;color:var(--blanc);font-family:'Jost',sans-serif;font-size:0.85rem;width:100%;">
          </div>
        </div>

        <!-- Genre -->
        <div style="margin-bottom:2rem;">
          <div class="subtitle" style="margin-bottom:0.75rem;">Genre</div>
          <?php foreach (['all' => 'Tous', 'femme' => 'Pour Elle', 'homme' => 'Pour Lui', 'mixte' => 'Mixte'] as $val => $label): ?>
          <label style="display:flex;align-items:center;gap:0.75rem;cursor:pointer;padding:0.4rem 0;color:<?= ($genre === $val) ? 'var(--or)' : '#888' ?>;font-size:0.85rem;">
            <input type="radio" name="genre" value="<?= $val ?>" <?= ($genre === $val) ? 'checked' : '' ?> onchange="this.form.submit()"
                   style="accent-color:var(--or);">
            <?= $label ?>
          </label>
          <?php endforeach; ?>
        </div>

        <!-- Catégories -->
        <div style="margin-bottom:2rem;">
          <div class="subtitle" style="margin-bottom:0.75rem;">Catégories</div>
          <label style="display:flex;align-items:center;gap:0.75rem;cursor:pointer;padding:0.4rem 0;color:<?= !$cat ? 'var(--or)' : '#888' ?>;font-size:0.85rem;">
            <input type="radio" name="cat" value="0" <?= !$cat ? 'checked' : '' ?> onchange="this.form.submit()" style="accent-color:var(--or);">
            Toutes
          </label>
          <?php foreach ($categories as $c): ?>
          <label style="display:flex;align-items:center;gap:0.75rem;cursor:pointer;padding:0.4rem 0;color:<?= ($cat == $c['id']) ? 'var(--or)' : '#888' ?>;font-size:0.85rem;">
            <input type="radio" name="cat" value="<?= $c['id'] ?>" <?= ($cat == $c['id']) ? 'checked' : '' ?> onchange="this.form.submit()" style="accent-color:var(--or);">
            <?= htmlspecialchars($c['nom']) ?>
          </label>
          <?php endforeach; ?>
        </div>

        <!-- Prix -->
        <div style="margin-bottom:2rem;">
          <div class="subtitle" style="margin-bottom:0.75rem;">Prix</div>
          <div style="display:flex;gap:0.5rem;align-items:center;">
            <input type="number" name="min" value="<?= $min_price ?>" placeholder="Min" min="0"
                   style="width:80px;background:var(--gris-fonce);border:1px solid rgba(201,169,110,0.2);color:var(--blanc);padding:0.4rem 0.5rem;font-size:0.8rem;outline:none;">
            <span style="color:#888;">—</span>
            <input type="number" name="max" value="<?= $max_price < 999 ? $max_price : '' ?>" placeholder="Max" min="0"
                   style="width:80px;background:var(--gris-fonce);border:1px solid rgba(201,169,110,0.2);color:var(--blanc);padding:0.4rem 0.5rem;font-size:0.8rem;outline:none;">
          </div>
          <button type="submit" class="btn btn-outline btn-sm" style="margin-top:0.75rem;">Appliquer</button>
        </div>

        <!-- Tri -->
        <div>
          <div class="subtitle" style="margin-bottom:0.75rem;">Trier par</div>
          <select name="sort" class="form-control" style="font-size:0.8rem;" onchange="this.form.submit()">
            <option value="popular" <?= $sort === 'popular' ? 'selected' : '' ?>>Popularité</option>
            <option value="rating" <?= $sort === 'rating' ? 'selected' : '' ?>>Meilleures notes</option>
            <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Prix croissant</option>
            <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Prix décroissant</option>
            <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Nouveautés</option>
          </select>
        </div>

        <a href="catalogue.php" class="btn btn-dark btn-sm" style="margin-top:1.5rem;width:100%;justify-content:center;">Réinitialiser</a>
      </form>
    </aside>

    <!-- GRILLE PRODUITS -->
    <main style="padding:2.5rem 3rem;">
      <?php if (empty($products)): ?>
        <div style="text-align:center;padding:6rem 2rem;">
          <div style="font-size:4rem;margin-bottom:1.5rem;">🔍</div>
          <h2 style="font-family:'Cormorant Garamond',serif;font-size:2rem;font-weight:300;">Aucun résultat</h2>
          <p style="color:#888;margin-top:0.75rem;">Modifiez vos critères de recherche</p>
          <a href="catalogue.php" class="btn btn-outline" style="margin-top:2rem;">Voir tout</a>
        </div>
      <?php else: ?>
        <div class="products-grid">
          <?php foreach ($products as $p): 
            $emoji = getEmoji($p['genre']);
            $stars = str_repeat('★', round($p['note_moyenne'])) . str_repeat('☆', 5 - round($p['note_moyenne']));
          ?>
          <div class="product-card" data-genre="<?= $p['genre'] ?>" data-name="<?= htmlspecialchars($p['nom']) ?>" data-brand="<?= htmlspecialchars($p['marque']) ?>">
            <div class="product-image">
              <?php if ($p['note_moyenne'] >= 4.8): ?>
                <span class="product-badge">★ Top</span>
              <?php endif; ?>
              <span class="product-emoji"><?= $emoji ?></span>
              <div class="product-actions">
                <a href="product.php?id=<?= $p['id'] ?>" class="btn btn-outline btn-sm">Détails</a>
                <button class="btn btn-primary btn-sm btn-add-cart" data-id="<?= $p['id'] ?>">+ Panier</button>
              </div>
            </div>
            <div class="product-info">
              <div class="product-brand"><?= htmlspecialchars($p['marque']) ?></div>
              <div class="product-name"><?= htmlspecialchars($p['nom']) ?></div>
              <div class="product-stars"><?= $stars ?><span>(<?= $p['nb_avis'] ?>)</span></div>
              <div style="font-size:0.72rem;color:#666;margin-bottom:0.5rem;">
                <?= htmlspecialchars($p['cat_nom'] ?? '') ?> · <?= htmlspecialchars($p['volume'] ?? '') ?>
              </div>
              <div class="product-footer">
                <span class="product-price"><?= formatPrice($p['prix']) ?></span>
                <?php if ($p['stock'] < 5 && $p['stock'] > 0): ?>
                  <span style="font-size:0.65rem;color:#e74c3c;letter-spacing:0.1em;">DERNIERS <?= $p['stock'] ?></span>
                <?php elseif ($p['stock'] == 0): ?>
                  <span style="font-size:0.65rem;color:#888;">RUPTURE</span>
                <?php else: ?>
                  <button class="btn-add-cart" data-id="<?= $p['id'] ?>">+ Panier</button>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </main>
  </div>
</main>

<?php include '../includes/footer.php'; ?>
