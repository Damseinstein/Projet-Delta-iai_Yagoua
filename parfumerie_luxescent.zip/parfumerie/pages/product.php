<?php
require_once '../includes/config.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(SITE_URL . '/pages/catalogue.php');

$stmt = $pdo->prepare("SELECT p.*, c.nom as cat_nom FROM produits p LEFT JOIN categories c ON p.categorie_id = c.id WHERE p.id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) redirect(SITE_URL . '/pages/catalogue.php');

// Avis
$avis = $pdo->prepare("SELECT a.*, u.prenom, u.nom FROM avis a JOIN utilisateurs u ON a.utilisateur_id = u.id WHERE a.produit_id = ? ORDER BY a.date_avis DESC LIMIT 10");
$avis->execute([$id]);
$reviews = $avis->fetchAll();

// Produits similaires
$similar = $pdo->prepare("SELECT * FROM produits WHERE genre = ? AND id != ? AND statut = 'actif' ORDER BY note_moyenne DESC LIMIT 4");
$similar->execute([$product['genre'], $id]);
$similarProducts = $similar->fetchAll();

// Soumission d'avis
$reviewError = '';
$reviewSuccess = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_review'])) {
    if (!isLoggedIn()) {
        $reviewError = 'Vous devez être connecté pour laisser un avis.';
    } else {
        $note = (int)$_POST['note'];
        $comment = sanitize($_POST['commentaire'] ?? '');
        if ($note < 1 || $note > 5) $reviewError = 'Note invalide.';
        elseif (!$comment) $reviewError = 'Le commentaire est obligatoire.';
        else {
            // Vérifier si avis déjà laissé
            $check = $pdo->prepare("SELECT id FROM avis WHERE produit_id = ? AND utilisateur_id = ?");
            $check->execute([$id, $_SESSION['user_id']]);
            if ($check->fetch()) {
                $reviewError = 'Vous avez déjà laissé un avis pour ce produit.';
            } else {
                $ins = $pdo->prepare("INSERT INTO avis (produit_id, utilisateur_id, note, commentaire) VALUES (?,?,?,?)");
                $ins->execute([$id, $_SESSION['user_id'], $note, $comment]);
                // Mettre à jour la note moyenne
                $pdo->prepare("UPDATE produits SET note_moyenne = (SELECT AVG(note) FROM avis WHERE produit_id = ?), nb_avis = (SELECT COUNT(*) FROM avis WHERE produit_id = ?) WHERE id = ?")->execute([$id, $id, $id]);
                $reviewSuccess = 'Votre avis a été publié !';
                redirect(SITE_URL . '/pages/product.php?id=' . $id . '#avis');
            }
        }
    }
}

$pageTitle = htmlspecialchars($product['nom']) . ' - LUXE SCENT';
$emojis = ['femme' => '🌸', 'homme' => '🌿', 'mixte' => '✨'];
$emoji = $emojis[$product['genre']] ?? '🌺';
$stars = str_repeat('★', round($product['note_moyenne'])) . str_repeat('☆', 5 - round($product['note_moyenne']));

include '../includes/header.php';
?>

<main style="padding-top:70px;">
  <!-- BREADCRUMB -->
  <div style="padding:1rem 6rem;font-size:0.75rem;color:#666;border-bottom:1px solid rgba(201,169,110,0.08);">
    <a href="<?= SITE_URL ?>" style="color:#888;text-decoration:none;">Accueil</a>
    <span style="margin:0 0.5rem;color:var(--or);">›</span>
    <a href="<?= SITE_URL ?>/pages/catalogue.php" style="color:#888;text-decoration:none;">Collection</a>
    <span style="margin:0 0.5rem;color:var(--or);">›</span>
    <span style="color:var(--or)"><?= htmlspecialchars($product['nom']) ?></span>
  </div>

  <!-- PRODUIT DÉTAIL -->
  <div class="product-detail">
    <!-- Image -->
    <div>
      <div class="product-detail-image" style="font-size:12rem;">
        <?= $emoji ?>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0.5rem;margin-top:0.75rem;">
        <?php for ($i = 0; $i < 4; $i++): ?>
        <div style="background:var(--gris-fonce);height:80px;display:flex;align-items:center;justify-content:center;font-size:2.5rem;border:1px solid rgba(201,169,110,0.1);cursor:pointer;opacity:<?= $i === 0 ? 1 : 0.5 ?>;"><?= $emoji ?></div>
        <?php endfor; ?>
      </div>
    </div>

    <!-- Infos -->
    <div class="product-detail-info">
      <div class="product-detail-brand"><?= htmlspecialchars($product['marque']) ?></div>
      <h1 class="product-detail-name"><?= htmlspecialchars($product['nom']) ?></h1>
      
      <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
        <div style="color:var(--or);font-size:1.1rem;"><?= $stars ?></div>
        <span style="color:#888;font-size:0.8rem;"><?= $product['nb_avis'] ?> avis</span>
        <span style="background:rgba(201,169,110,0.15);color:var(--or);padding:0.2rem 0.6rem;font-size:0.65rem;letter-spacing:0.1em;text-transform:uppercase;">
          <?= ucfirst($product['genre']) ?>
        </span>
      </div>

      <div class="product-detail-price">
        <?= formatPrice($product['prix']) ?>
        <?php if ($product['volume']): ?>
          <span style="font-size:1rem;color:#888;margin-left:0.5rem;"><?= htmlspecialchars($product['volume']) ?></span>
        <?php endif; ?>
      </div>

      <p class="product-detail-desc"><?= nl2br(htmlspecialchars($product['description'])) ?></p>

      <!-- Stock -->
      <div style="margin-bottom:1.5rem;padding:0.75rem 1rem;background:rgba(201,169,110,0.05);border-left:3px solid var(--or);">
        <?php if ($product['stock'] > 10): ?>
          <span style="color:#2ecc71;font-size:0.8rem;">✓ En stock (<?= $product['stock'] ?> disponibles)</span>
        <?php elseif ($product['stock'] > 0): ?>
          <span style="color:#e67e22;font-size:0.8rem;">⚠ Derniers exemplaires (<?= $product['stock'] ?> en stock)</span>
        <?php else: ?>
          <span style="color:#e74c3c;font-size:0.8rem;">✗ Rupture de stock</span>
        <?php endif; ?>
      </div>

      <?php if ($product['stock'] > 0): ?>
      <!-- Quantité + Ajouter au panier -->
      <div class="quantity-selector">
        <div class="qty-control">
          <button class="qty-minus" type="button">−</button>
          <input type="number" id="quantity" value="1" min="1" max="<?= $product['stock'] ?>">
          <button class="qty-plus" type="button">+</button>
        </div>
        <button class="btn btn-primary" data-add-cart data-id="<?= $product['id'] ?>" style="flex:1;">
          🛍️ Ajouter au Panier
        </button>
      </div>
      <?php endif; ?>

      <!-- Détails techniques -->
      <div style="border-top:1px solid rgba(201,169,110,0.12);padding-top:1.5rem;margin-top:1rem;">
        <div class="subtitle" style="margin-bottom:1rem;">Informations</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;font-size:0.82rem;">
          <div style="color:#888;">Marque</div><div style="color:var(--blanc)"><?= htmlspecialchars($product['marque']) ?></div>
          <div style="color:#888;">Volume</div><div style="color:var(--blanc)"><?= htmlspecialchars($product['volume'] ?? 'N/A') ?></div>
          <div style="color:#888;">Genre</div><div style="color:var(--blanc)"><?= ucfirst($product['genre']) ?></div>
          <div style="color:#888;">Catégorie</div><div style="color:var(--blanc)"><?= htmlspecialchars($product['cat_nom'] ?? 'N/A') ?></div>
        </div>
      </div>
    </div>
  </div>

  <!-- AVIS -->
  <div id="avis" style="padding:4rem 6rem;border-top:1px solid rgba(201,169,110,0.1);">
    <h2 style="font-family:'Cormorant Garamond',serif;font-size:2.2rem;font-weight:300;margin-bottom:2.5rem;">
      Avis Clients <span style="color:#888;font-size:1.2rem;">(<?= count($reviews) ?>)</span>
    </h2>

    <?php if ($reviewError): ?><div class="alert alert-error"><?= $reviewError ?></div><?php endif; ?>
    <?php if ($reviewSuccess): ?><div class="alert alert-success"><?= $reviewSuccess ?></div><?php endif; ?>

    <div style="display:grid;grid-template-columns:2fr 1fr;gap:3rem;">
      <!-- Liste avis -->
      <div>
        <?php if (empty($reviews)): ?>
          <p style="color:#888;font-style:italic;">Aucun avis pour ce produit. Soyez le premier !</p>
        <?php else: ?>
          <?php foreach ($reviews as $r): ?>
          <div style="padding:1.5rem 0;border-bottom:1px solid rgba(255,255,255,0.05);">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.5rem;">
              <div>
                <strong style="font-size:0.9rem;"><?= htmlspecialchars($r['prenom']) ?> <?= htmlspecialchars(substr($r['nom'], 0, 1)) ?>.</strong>
                <span style="color:var(--or);font-size:0.9rem;margin-left:0.75rem;"><?= str_repeat('★', $r['note']) ?></span>
              </div>
              <span style="color:#888;font-size:0.75rem;"><?= date('d/m/Y', strtotime($r['date_avis'])) ?></span>
            </div>
            <p style="color:#aaa;font-size:0.87rem;line-height:1.7;"><?= htmlspecialchars($r['commentaire']) ?></p>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <!-- Formulaire avis -->
      <div>
        <div class="admin-card">
          <div class="admin-card-header">
            <span class="admin-card-title">Laisser un avis</span>
          </div>
          <div class="admin-card-body">
            <?php if (!isLoggedIn()): ?>
              <p style="color:#888;font-size:0.85rem;">
                <a href="<?= SITE_URL ?>/pages/login.php" style="color:var(--or);">Connectez-vous</a> pour laisser un avis.
              </p>
            <?php else: ?>
            <form method="POST">
              <div class="form-group">
                <label class="form-label">Note</label>
                <div style="display:flex;gap:0.5rem;">
                  <?php for ($i = 1; $i <= 5; $i++): ?>
                  <label style="cursor:pointer;font-size:1.5rem;color:rgba(201,169,110,0.3);transition:color 0.2s;" 
                         onmouseover="highlightStars(<?= $i ?>)" onmouseout="resetStars()">
                    <input type="radio" name="note" value="<?= $i ?>" style="display:none;" required>
                    <span class="star-label">★</span>
                  </label>
                  <?php endfor; ?>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Commentaire</label>
                <textarea name="commentaire" class="form-control" placeholder="Décrivez votre expérience..." required></textarea>
              </div>
              <button type="submit" name="add_review" class="btn btn-primary w-100">Publier</button>
            </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- PRODUITS SIMILAIRES -->
  <?php if (!empty($similarProducts)): ?>
  <div style="padding:4rem 6rem;border-top:1px solid rgba(201,169,110,0.1);">
    <h2 style="font-family:'Cormorant Garamond',serif;font-size:2.2rem;font-weight:300;margin-bottom:2rem;">
      Vous aimerez aussi
    </h2>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem;">
      <?php foreach ($similarProducts as $sp): 
        $se = $emojis[$sp['genre']] ?? '🌺';
      ?>
      <a href="product.php?id=<?= $sp['id'] ?>" style="text-decoration:none;">
        <div class="product-card" style="cursor:pointer;">
          <div class="product-image" style="height:200px;">
            <span class="product-emoji"><?= $se ?></span>
          </div>
          <div class="product-info">
            <div class="product-brand"><?= htmlspecialchars($sp['marque']) ?></div>
            <div class="product-name" style="font-size:1.1rem;"><?= htmlspecialchars($sp['nom']) ?></div>
            <div class="product-footer">
              <span class="product-price"><?= formatPrice($sp['prix']) ?></span>
            </div>
          </div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</main>

<script>
// Star rating hover
const labels = document.querySelectorAll('.star-label');
let selectedRating = 0;
function highlightStars(n) {
  labels.forEach((l, i) => {
    l.style.color = i < n ? 'var(--or)' : 'rgba(201,169,110,0.3)';
  });
}
function resetStars() {
  labels.forEach((l, i) => {
    l.style.color = i < selectedRating ? 'var(--or)' : 'rgba(201,169,110,0.3)';
  });
}
document.querySelectorAll('input[name="note"]').forEach((radio, i) => {
  radio.addEventListener('change', () => {
    selectedRating = i + 1;
    highlightStars(selectedRating);
  });
});

// Qty controls
document.querySelector('.qty-minus')?.addEventListener('click', () => {
  const inp = document.getElementById('quantity');
  if (parseInt(inp.value) > 1) inp.value--;
});
document.querySelector('.qty-plus')?.addEventListener('click', () => {
  const inp = document.getElementById('quantity');
  if (parseInt(inp.value) < parseInt(inp.max)) inp.value++;
});
</script>

<?php include '../includes/footer.php'; ?>
