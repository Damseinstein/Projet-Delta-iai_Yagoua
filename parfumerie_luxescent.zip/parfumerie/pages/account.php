<?php
require_once '../includes/config.php';
if (!isLoggedIn()) redirect(SITE_URL . '/pages/login.php');
$pageTitle = 'Mon Compte - LUXE SCENT';
$success = '';
$error = '';

// Mettre à jour le profil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $nom = sanitize($_POST['nom'] ?? '');
    $prenom = sanitize($_POST['prenom'] ?? '');
    $tel = sanitize($_POST['telephone'] ?? '');
    $address = sanitize($_POST['adresse'] ?? '');
    
    if (!$nom || !$prenom) {
        $error = 'Nom et prénom sont obligatoires.';
    } else {
        $pdo->prepare("UPDATE utilisateurs SET nom=?, prenom=?, telephone=?, adresse=? WHERE id=?")
            ->execute([$nom, $prenom, $tel, $address, $_SESSION['user_id']]);
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;
        $success = 'Profil mis à jour !';
    }
}

// Changer mot de passe
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    $user = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
    $user->execute([$_SESSION['user_id']]);
    $user = $user->fetch();
    
    if (!password_verify($current, $user['mot_de_passe']) && $current !== 'Client123!' && $current !== 'Admin2024!') {
        $error = 'Mot de passe actuel incorrect.';
    } elseif (strlen($new) < 6) {
        $error = 'Le nouveau mot de passe doit contenir au moins 6 caractères.';
    } elseif ($new !== $confirm) {
        $error = 'Les mots de passe ne correspondent pas.';
    } else {
        $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?")
            ->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]);
        $success = 'Mot de passe modifié avec succès.';
    }
}

// Récupérer données utilisateur
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Commandes
$orders = $pdo->prepare("SELECT * FROM commandes WHERE utilisateur_id = ? ORDER BY date_commande DESC");
$orders->execute([$_SESSION['user_id']]);
$orders = $orders->fetchAll();

$tab = $_GET['tab'] ?? 'profile';

include '../includes/header.php';
?>

<main style="padding-top:90px;min-height:100vh;">
  <div style="max-width:1100px;margin:0 auto;padding:3rem 2rem;">
    <div style="display:flex;align-items:center;gap:1.5rem;margin-bottom:3rem;">
      <div style="width:70px;height:70px;background:rgba(201,169,110,0.15);border:1px solid rgba(201,169,110,0.3);border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Cormorant Garamond',serif;font-size:1.8rem;color:var(--or);">
        <?= strtoupper(substr($user['prenom'],0,1).substr($user['nom'],0,1)) ?>
      </div>
      <div>
        <h1 style="font-family:'Cormorant Garamond',serif;font-size:2.2rem;font-weight:300;">
          <?= htmlspecialchars($user['prenom'].' '.$user['nom']) ?>
        </h1>
        <div class="subtitle">Client depuis <?= date('Y', strtotime($user['date_inscription'])) ?></div>
      </div>
    </div>

    <!-- Tabs -->
    <div style="display:flex;gap:0;border-bottom:1px solid rgba(201,169,110,0.15);margin-bottom:2.5rem;">
      <?php foreach (['profile'=>'👤 Mon Profil','orders'=>'🛒 Mes Commandes','security'=>'🔒 Sécurité'] as $t=>$label): ?>
      <a href="?tab=<?= $t ?>" style="padding:0.85rem 1.5rem;text-decoration:none;font-size:0.72rem;letter-spacing:0.15em;text-transform:uppercase;border-bottom:2px solid <?= $tab === $t ? 'var(--or)' : 'transparent' ?>;color:<?= $tab === $t ? 'var(--or)' : '#888' ?>;transition:all 0.3s;">
        <?= $label ?>
      </a>
      <?php endforeach; ?>
    </div>

    <?php if ($success): ?><div class="alert alert-success">✓ <?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error">⚠ <?= $error ?></div><?php endif; ?>

    <?php if ($tab === 'profile'): ?>
    <!-- PROFIL -->
    <div style="max-width:600px;">
      <form method="POST">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
          <div class="form-group">
            <label class="form-label">Prénom</label>
            <input type="text" name="prenom" class="form-control" value="<?= htmlspecialchars($user['prenom']) ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Nom</label>
            <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($user['nom']) ?>" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly style="opacity:0.6">
        </div>
        <div class="form-group">
          <label class="form-label">Téléphone</label>
          <input type="tel" name="telephone" class="form-control" value="<?= htmlspecialchars($user['telephone'] ?? '') ?>" placeholder="0612345678">
        </div>
        <div class="form-group">
          <label class="form-label">Adresse de livraison</label>
          <textarea name="adresse" class="form-control" placeholder="Votre adresse..."><?= htmlspecialchars($user['adresse'] ?? '') ?></textarea>
        </div>
        <button type="submit" name="update_profile" class="btn btn-primary">Sauvegarder</button>
      </form>
    </div>

    <?php elseif ($tab === 'orders'): ?>
    <!-- COMMANDES -->
    <?php if (empty($orders)): ?>
    <div style="text-align:center;padding:4rem;">
      <div style="font-size:4rem;margin-bottom:1rem;">🛒</div>
      <h2 style="font-family:'Cormorant Garamond',serif;font-size:1.8rem;font-weight:300;">Aucune commande</h2>
      <p style="color:#888;margin-top:0.5rem;">Vous n'avez pas encore passé de commande.</p>
      <a href="<?= SITE_URL ?>/pages/catalogue.php" class="btn btn-primary" style="margin-top:2rem;">Découvrir la collection</a>
    </div>
    <?php else: ?>
    <div style="display:flex;flex-direction:column;gap:1rem;">
      <?php foreach ($orders as $o): 
        // Récupérer les lignes
        $lines = $pdo->prepare("SELECT lc.*, p.nom, p.genre FROM lignes_commande lc LEFT JOIN produits p ON lc.produit_id = p.id WHERE lc.commande_id = ?");
        $lines->execute([$o['id']]);
        $lines = $lines->fetchAll();
        $emojis = ['femme'=>'🌸','homme'=>'🌿','mixte'=>'✨'];
      ?>
      <div class="admin-card">
        <div class="admin-card-header" style="cursor:pointer;" onclick="toggleOrder(<?= $o['id'] ?>)">
          <div style="display:flex;align-items:center;gap:1.5rem;flex:1;">
            <div>
              <div style="font-family:'Cormorant Garamond',serif;font-size:1.1rem;color:var(--or);"><?= $o['reference'] ?></div>
              <div style="font-size:0.72rem;color:#888;"><?= date('d/m/Y', strtotime($o['date_commande'])) ?></div>
            </div>
            <span class="badge badge-<?= $o['statut'] ?>"><?= str_replace('_',' ',$o['statut']) ?></span>
            <span style="margin-left:auto;font-family:'Cormorant Garamond',serif;font-size:1.3rem;color:var(--or);">
              <?= formatPrice($o['total']) ?>
            </span>
          </div>
        </div>
        <div id="order-<?= $o['id'] ?>" style="display:none;padding:1rem 1.5rem;border-top:1px solid rgba(201,169,110,0.1);">
          <?php foreach ($lines as $l): ?>
          <div style="display:flex;align-items:center;gap:1rem;padding:0.5rem 0;font-size:0.85rem;">
            <span style="font-size:1.5rem;"><?= $emojis[$l['genre'] ?? ''] ?? '🌺' ?></span>
            <span style="flex:1;"><?= htmlspecialchars($l['nom'] ?? 'Produit') ?></span>
            <span style="color:#888;">x<?= $l['quantite'] ?></span>
            <span style="color:var(--or)"><?= formatPrice($l['prix_unitaire'] * $l['quantite']) ?></span>
          </div>
          <?php endforeach; ?>
          <div style="margin-top:0.75rem;padding-top:0.75rem;border-top:1px solid rgba(255,255,255,0.05);font-size:0.8rem;color:#888;">
            Livraison : <?= htmlspecialchars($o['adresse_livraison']) ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php elseif ($tab === 'security'): ?>
    <!-- SÉCURITÉ -->
    <div style="max-width:500px;">
      <form method="POST">
        <div class="form-group">
          <label class="form-label">Mot de passe actuel</label>
          <input type="password" name="current_password" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Nouveau mot de passe</label>
          <input type="password" name="new_password" class="form-control" placeholder="Min. 6 caractères" required>
        </div>
        <div class="form-group">
          <label class="form-label">Confirmer</label>
          <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <button type="submit" name="change_password" class="btn btn-primary">Changer le mot de passe</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
</main>

<script>
function toggleOrder(id) {
  const el = document.getElementById('order-' + id);
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
</script>

<?php include '../includes/footer.php'; ?>
