<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? 'get';

// GET CART
if ($action === 'get') {
    if (!isLoggedIn()) {
        echo json_encode(['items' => [], 'total' => 0, 'count' => 0]);
        exit;
    }
    $stmt = $pdo->prepare("
        SELECT p.id as produit_id, p.nom, p.marque, p.prix, p.genre, p.stock, pa.quantite
        FROM panier pa 
        JOIN produits p ON pa.produit_id = p.id 
        WHERE pa.utilisateur_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $items = $stmt->fetchAll();
    
    $emojis = ['femme' => '🌸', 'homme' => '🌿', 'mixte' => '✨'];
    foreach ($items as &$item) {
        $item['emoji'] = $emojis[$item['genre']] ?? '🌺';
    }
    
    $total = array_sum(array_map(fn($i) => $i['prix'] * $i['quantite'], $items));
    $count = array_sum(array_column($items, 'quantite'));
    
    echo json_encode(['items' => $items, 'total' => $total, 'count' => $count]);
    exit;
}

// ADD TO CART
if ($action === 'add') {
    if (!isLoggedIn()) {
        echo json_encode(['success' => false, 'message' => 'Connexion requise', 'redirect' => SITE_URL . '/pages/login.php']);
        exit;
    }
    $productId = (int)($_POST['product_id'] ?? 0);
    $qty = max(1, (int)($_POST['qty'] ?? 1));
    
    if (!$productId) {
        echo json_encode(['success' => false, 'message' => 'Produit invalide']);
        exit;
    }
    
    // Vérifier stock
    $stmt = $pdo->prepare("SELECT stock FROM produits WHERE id = ? AND statut = 'actif'");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    
    if (!$product || $product['stock'] < 1) {
        echo json_encode(['success' => false, 'message' => 'Produit indisponible']);
        exit;
    }
    
    // Insérer ou mettre à jour le panier
    $stmt = $pdo->prepare("
        INSERT INTO panier (utilisateur_id, produit_id, quantite) 
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quantite = LEAST(quantite + VALUES(quantite), ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $productId, $qty, $product['stock']]);
    
    // Compter les articles
    $countStmt = $pdo->prepare("SELECT SUM(quantite) FROM panier WHERE utilisateur_id = ?");
    $countStmt->execute([$_SESSION['user_id']]);
    $count = (int)$countStmt->fetchColumn();
    
    echo json_encode(['success' => true, 'count' => $count]);
    exit;
}

// UPDATE CART
if ($action === 'update') {
    if (!isLoggedIn()) {
        echo json_encode(['success' => false]);
        exit;
    }
    $productId = (int)($_POST['product_id'] ?? 0);
    $delta = (int)($_POST['delta'] ?? 0);
    
    // Vérifier la quantité actuelle
    $stmt = $pdo->prepare("SELECT quantite FROM panier WHERE utilisateur_id = ? AND produit_id = ?");
    $stmt->execute([$_SESSION['user_id'], $productId]);
    $current = $stmt->fetchColumn();
    
    $newQty = max(0, ($current ?: 0) + $delta);
    
    if ($newQty === 0) {
        $pdo->prepare("DELETE FROM panier WHERE utilisateur_id = ? AND produit_id = ?")->execute([$_SESSION['user_id'], $productId]);
    } else {
        // Vérifier stock
        $stock = $pdo->prepare("SELECT stock FROM produits WHERE id = ?")->execute([$productId]);
        $pdo->prepare("UPDATE panier SET quantite = ? WHERE utilisateur_id = ? AND produit_id = ?")->execute([min($newQty, 99), $_SESSION['user_id'], $productId]);
    }
    
    echo json_encode(['success' => true]);
    exit;
}

// REMOVE FROM CART
if ($action === 'remove') {
    if (!isLoggedIn()) {
        echo json_encode(['success' => false]);
        exit;
    }
    $productId = (int)($_POST['product_id'] ?? 0);
    $pdo->prepare("DELETE FROM panier WHERE utilisateur_id = ? AND produit_id = ?")->execute([$_SESSION['user_id'], $productId]);
    echo json_encode(['success' => true]);
    exit;
}

// CLEAR CART
if ($action === 'clear') {
    if (!isLoggedIn()) {
        echo json_encode(['success' => false]);
        exit;
    }
    $pdo->prepare("DELETE FROM panier WHERE utilisateur_id = ?")->execute([$_SESSION['user_id']]);
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['error' => 'Action inconnue']);
