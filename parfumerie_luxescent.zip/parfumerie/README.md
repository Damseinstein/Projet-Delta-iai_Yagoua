# 🌸 LUXE SCENT — Application de Gestion de Parfumerie
## Guide d'Installation & Documentation

---

## 📋 ANALYSE MERISE

### MCD — Modèle Conceptuel de Données

**Entités identifiées :**
- **PRODUIT** : id, nom, marque, description, prix, prix_promo, stock, volume, image, genre, note_moyenne, nb_avis, statut, created_at
- **CATEGORIE** : id, nom, description, created_at
- **UTILISATEUR** : id, nom, prenom, email, mot_de_passe, role, telephone, adresse, date_inscription, actif
- **COMMANDE** : id, reference, date_commande, total, statut, adresse_livraison, methode_paiement, notes
- **LIGNE_COMMANDE** : id, quantite, prix_unitaire *(table associative)*
- **AVIS** : id, note, commentaire, date_avis
- **PANIER** : id, quantite, added_at *(table associative)*
- **CODE_PROMO** : id, code, reduction, type_reduction, date_debut, date_fin, utilisation_max, utilisation_actuelle, actif

**Associations :**
- PRODUIT **appartient à** CATEGORIE (N:1)
- UTILISATEUR **passe** COMMANDE (1:N)
- COMMANDE **contient** PRODUIT via LIGNE_COMMANDE (N:M)
- UTILISATEUR **donne** AVIS sur PRODUIT (N:M)
- UTILISATEUR **a** PANIER contenant PRODUIT (N:M)

### MLD — Modèle Logique de Données
```
categories(id, nom, description, created_at)
utilisateurs(id, nom, prenom, email, mot_de_passe, role, telephone, adresse, date_inscription, actif)
produits(id, nom, marque, description, prix, prix_promo, stock, volume, image, #categorie_id, genre, note_moyenne, nb_avis, statut, created_at)
commandes(id, #utilisateur_id, reference, date_commande, total, statut, adresse_livraison, methode_paiement)
lignes_commande(id, #commande_id, #produit_id, quantite, prix_unitaire)
panier(id, #utilisateur_id, #produit_id, quantite, added_at)
avis(id, #produit_id, #utilisateur_id, note, commentaire, date_avis)
codes_promo(id, code, reduction, type_reduction, date_debut, date_fin, utilisation_max, utilisation_actuelle, actif)
```

---

## 🚀 INSTALLATION (WampServer)

### Prérequis
- WampServer 3.x (PHP 7.4+ ou 8.x)
- Apache activé
- MySQL/MariaDB activé

### Étapes

**1. Copier le projet**
```
Copier le dossier `parfumerie` dans :
C:\wamp64\www\parfumerie\
```

**2. Créer la base de données**
- Ouvrir phpMyAdmin : http://localhost/phpmyadmin
- Importer le fichier `database.sql`
- OU exécuter le SQL manuellement

**3. Configurer la connexion**
Éditer `includes/config.php` si nécessaire :
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');         // Votre mot de passe WampServer
define('DB_NAME', 'parfumerie_db');
define('SITE_URL', 'http://localhost/parfumerie');
```

**4. Accéder à l'application**
- **Boutique :** http://localhost/parfumerie/
- **Admin :** http://localhost/parfumerie/admin/

---

## 🔑 COMPTES DE DÉMONSTRATION

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| Admin | admin@luxescent.fr | Admin2024! |
| Client | sophie.martin@email.fr | Client123! |

---

## ✨ FONCTIONNALITÉS

### 🛍️ Boutique (Frontend)
1. **Catalogue produits** — Grille de produits avec filtres (genre, catégorie, prix, recherche)
2. **Fiche produit** — Détail, galerie, notes & avis clients
3. **Panier dynamique** — Sidebar AJAX, gestion des quantités
4. **Commande** — Checkout complet avec codes promo
5. **Compte client** — Profil, historique commandes, sécurité

### 🔧 Administration (Backend)
1. **Dashboard** — Statistiques, alertes stock, top ventes
2. **Gestion produits** — CRUD complet (ajout, modification, désactivation)
3. **Gestion commandes** — Liste, détail, changement de statut
4. **Gestion clients** — Liste, suspension/réactivation
5. **Codes promo** — Création, activation/désactivation
6. **Catégories** — CRUD des catégories

---

## 📁 STRUCTURE DES FICHIERS

```
parfumerie/
├── index.php              # Page d'accueil
├── database.sql           # Script SQL (MLD + données)
├── README.md              # Ce fichier
├── includes/
│   ├── config.php         # Configuration DB + fonctions utilitaires
│   ├── header.php         # En-tête + navigation + panier sidebar
│   └── footer.php         # Pied de page
├── pages/
│   ├── catalogue.php      # Catalogue avec filtres
│   ├── product.php        # Fiche produit + avis
│   ├── checkout.php       # Processus de commande
│   ├── account.php        # Espace client
│   ├── login.php          # Connexion / Inscription
│   ├── register.php       # Redirection inscription
│   └── logout.php         # Déconnexion
├── admin/
│   ├── index.php          # Dashboard admin
│   ├── sidebar.php        # Navigation admin
│   ├── products.php       # Gestion produits
│   ├── orders.php         # Gestion commandes
│   ├── clients.php        # Gestion clients
│   ├── categories.php     # Gestion catégories
│   └── promos.php         # Codes promo
├── ajax/
│   └── cart.php           # API AJAX panier
└── assets/
    ├── css/style.css      # Styles (Art Déco Luxury)
    └── js/main.js         # JavaScript interactif
```

---

## 🎨 DESIGN
- **Thème :** Luxury Art Déco — Noir & Or
- **Typographies :** Cormorant Garamond (serif) + Jost (sans-serif)
- **Palette :** #0a0a0a (fond), #c9a96e (or), #fafaf8 (blanc crème)
- **Design responsive** — Mobile, tablette, desktop
