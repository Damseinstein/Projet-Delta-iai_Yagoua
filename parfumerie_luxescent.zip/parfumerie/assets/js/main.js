// ============================================================
// LUXE SCENT - JavaScript Principal
// ============================================================

document.addEventListener('DOMContentLoaded', function() {

  // ── Panier Sidebar ──
  const cartBtn = document.getElementById('cartBtn');
  const cartSidebar = document.getElementById('cartSidebar');
  const cartClose = document.getElementById('cartClose');
  const overlayBg = document.getElementById('overlayBg');

  function openCart() {
    cartSidebar?.classList.add('open');
    overlayBg?.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  function closeCart() {
    cartSidebar?.classList.remove('open');
    overlayBg?.classList.remove('active');
    document.body.style.overflow = '';
  }

  cartBtn?.addEventListener('click', openCart);
  cartClose?.addEventListener('click', closeCart);
  overlayBg?.addEventListener('click', closeCart);

  // ── Modals ──
  document.querySelectorAll('[data-modal]').forEach(btn => {
    btn.addEventListener('click', function() {
      const modalId = this.dataset.modal;
      document.getElementById(modalId)?.classList.add('active');
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', function(e) {
      if (e.target === this) this.classList.remove('active');
    });
  });
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', function() {
      this.closest('.modal-overlay')?.classList.remove('active');
    });
  });

  // ── Filtres produits ──
  const filterBtns = document.querySelectorAll('.filter-btn');
  const productCards = document.querySelectorAll('.product-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      filterBtns.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      const filter = this.dataset.filter;
      productCards.forEach(card => {
        if (filter === 'all' || card.dataset.genre === filter || card.dataset.category === filter) {
          card.style.display = '';
          card.style.animation = 'fadeInUp 0.4s ease both';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // ── Recherche ──
  const searchInput = document.getElementById('searchInput');
  searchInput?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    productCards.forEach(card => {
      const name = card.dataset.name?.toLowerCase() || '';
      const brand = card.dataset.brand?.toLowerCase() || '';
      card.style.display = (!q || name.includes(q) || brand.includes(q)) ? '' : 'none';
    });
  });

  // ── Quantité ──
  document.querySelectorAll('.qty-minus').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.parentElement.querySelector('input');
      if (parseInt(input.value) > 1) input.value = parseInt(input.value) - 1;
    });
  });
  document.querySelectorAll('.qty-plus').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.parentElement.querySelector('input');
      const max = parseInt(input.max) || 99;
      if (parseInt(input.value) < max) input.value = parseInt(input.value) + 1;
    });
  });

  // ── Toast notifications ──
  window.showToast = function(msg, type = 'info') {
    const container = document.querySelector('.toast-container') || (() => {
      const c = document.createElement('div');
      c.className = 'toast-container';
      document.body.appendChild(c);
      return c;
    })();
    const icons = { success: '✓', error: '✗', info: '◆' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${icons[type] || '◆'}</span> ${msg}`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  };

  // ── Ajouter au panier (AJAX) ──
  document.querySelectorAll('.btn-add-cart, [data-add-cart]').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      const productId = this.dataset.id;
      const qty = document.getElementById('quantity')?.value || 1;
      if (!productId) return;

      fetch('ajax/cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=add&product_id=${productId}&qty=${qty}`
      })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          showToast('Produit ajouté au panier', 'success');
          // Update cart count
          const cartCount = document.querySelectorAll('.cart-count');
          cartCount.forEach(c => c.textContent = data.count);
          updateCartSidebar();
        } else {
          showToast(data.message || 'Veuillez vous connecter', 'error');
          if (data.redirect) window.location.href = data.redirect;
        }
      })
      .catch(() => showToast('Erreur réseau', 'error'));
    });
  });

  // ── Update cart sidebar ──
  window.updateCartSidebar = function() {
    fetch('ajax/cart.php?action=get')
      .then(r => r.json())
      .then(data => {
        const cartItems = document.getElementById('cartItems');
        const cartTotal = document.getElementById('cartTotal');
        const cartCount = document.querySelectorAll('.cart-count');
        if (!cartItems) return;

        if (!data.items || data.items.length === 0) {
          cartItems.innerHTML = '<div style="text-align:center;color:#888;padding:3rem 1rem;"><p style="font-family:Cormorant Garamond,serif;font-size:1.3rem">Votre panier est vide</p><p style="font-size:0.8rem;margin-top:0.5rem">Explorez notre collection</p></div>';
          if (cartTotal) cartTotal.textContent = '0,00 €';
          cartCount.forEach(c => c.textContent = '0');
          return;
        }

        let html = '';
        let total = 0;
        let count = 0;
        data.items.forEach(item => {
          const price = parseFloat(item.prix) * item.quantite;
          total += price;
          count += parseInt(item.quantite);
          html += `
            <div class="cart-item">
              <div class="cart-item-image">${item.emoji || '🌸'}</div>
              <div class="cart-item-info">
                <div class="cart-item-brand">${item.marque}</div>
                <div class="cart-item-name">${item.nom}</div>
                <div class="cart-item-price">${formatPrice(price)}</div>
              </div>
              <div class="cart-item-controls">
                <button class="qty-btn cart-qty-minus" data-id="${item.produit_id}">−</button>
                <span class="qty-display">${item.quantite}</span>
                <button class="qty-btn cart-qty-plus" data-id="${item.produit_id}">+</button>
                <button class="remove-btn cart-remove" data-id="${item.produit_id}" title="Supprimer">✕</button>
              </div>
            </div>`;
        });
        cartItems.innerHTML = html;
        if (cartTotal) cartTotal.textContent = formatPrice(total);
        cartCount.forEach(c => c.textContent = count);

        // Cart controls
        document.querySelectorAll('.cart-qty-minus').forEach(b => {
          b.addEventListener('click', () => updateCartItem(b.dataset.id, -1));
        });
        document.querySelectorAll('.cart-qty-plus').forEach(b => {
          b.addEventListener('click', () => updateCartItem(b.dataset.id, 1));
        });
        document.querySelectorAll('.cart-remove').forEach(b => {
          b.addEventListener('click', () => removeCartItem(b.dataset.id));
        });
      });
  };

  function formatPrice(n) {
    return n.toFixed(2).replace('.', ',') + ' €';
  }

  function updateCartItem(id, delta) {
    fetch('ajax/cart.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `action=update&product_id=${id}&delta=${delta}`
    }).then(r => r.json()).then(() => updateCartSidebar());
  }

  function removeCartItem(id) {
    fetch('ajax/cart.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `action=remove&product_id=${id}`
    }).then(r => r.json()).then(() => updateCartSidebar());
  }

  // Init cart on load
  if (document.getElementById('cartSidebar')) {
    updateCartSidebar();
  }

  // ── Header scroll effect ──
  const header = document.querySelector('.header');
  if (header) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > 50) {
        header.style.background = 'rgba(10, 10, 10, 0.98)';
      } else {
        header.style.background = 'rgba(10, 10, 10, 0.95)';
      }
    });
  }

  // ── Auto dismiss alerts ──
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity 0.5s ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 500);
    }, 4000);
  });

  // ── Admin: confirm delete ──
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', function(e) {
      if (!confirm(this.dataset.confirm || 'Confirmer la suppression ?')) {
        e.preventDefault();
      }
    });
  });

  // ── Admin: preview image upload ──
  const imageInput = document.getElementById('imageInput');
  const imagePreview = document.getElementById('imagePreview');
  if (imageInput && imagePreview) {
    imageInput.addEventListener('change', function() {
      if (this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
          imagePreview.src = e.target.result;
          imagePreview.style.display = 'block';
        };
        reader.readAsDataURL(this.files[0]);
      }
    });
  }

});
